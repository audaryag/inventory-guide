let
    Raw     = fnVarSheetSafe(
                  {"Plant Master", "PlantMaster", "Plants", "Plant"},
                  {
                    {{"Valuation Area","Val Area","Plant Code","Code","Plant"}, "ValuationArea"},
                    {{"Plant Name","Name","Description","Plant Description",
                      "Valuation Area Description"}, "PlantName"},
                    {{"Sort","Order","Sort Order"}, "PlantSort"},
                    {{"MWD","MW D","MWD (MW per day)","MW per Day","MW Day","MWPD"}, "PlantMWD"}
                  }),
    Cols    = {"ValuationArea", "PlantName", "PlantSort", "PlantMWD"},
    Padded  = List.Accumulate(List.Difference(Cols, Table.ColumnNames(Raw)), Raw,
                  (t, c) => Table.AddColumn(t, c, each null)),
    Slim    = Table.SelectColumns(Padded, Cols),
    // the code is text and trimmed, because 1900 read as a number will not join to a text key
    Keyed   = Table.TransformColumns(Slim, {
                  {"ValuationArea", each Text.Trim(Text.From(_ ?? "")), type text},
                  {"PlantName",     each Text.Trim(Text.From(_ ?? "")), type text}}),
    Real    = Table.SelectRows(Keyed, each [ValuationArea] <> ""),
    // the label the whole report shows: the code and the name together, so the slicer, the
    // legends and the ticker cards can never disagree about what a plant is called
    Label   = Table.AddColumn(Real, "Plant",
                  each if [PlantName] = "" then [ValuationArea]
                       else [ValuationArea] & " " & [PlantName], type text),
    Sorted  = Table.AddColumn(Label, "SortNo",
                  each try Number.From([PlantSort]) otherwise null, type number),
    Indexed = Table.AddIndexColumn(Sorted, "Seq", 1, 1, Int64.Type),
    Order   = Table.AddColumn(Indexed, "PlantSortNo",
                  each Int64.From([SortNo] ?? [Seq]), Int64.Type),
    // MWD - the plant's megawatts a day, typed on Plant Master. It is the denominator for
    // days of cover on the plant rows: days = inventory MW / MWD, nothing else divided in.
    Rate    = Table.AddColumn(Order, "MWD",
                  each let v = try Number.From([PlantMWD]) otherwise null
                       in  if v = null or v = 0 then null else v, type number),
    Out     = Table.SelectColumns(Rate, {"ValuationArea", "Plant", "PlantSortNo", "MWD"})
in
    Out
