let
    Src      = stgFG,
    // read once and held, for the same reason as factRM: two merges against it, and each one
    // would otherwise re-open the workbook
    AttrSrc  = Table.Buffer(dimFGAttr),
    Merged   = Table.NestedJoin(Src, {"MatKey"}, AttrSrc, {"MatKey"},
                   "attr", JoinKind.LeftOuter),
    Expanded = Table.ExpandTableColumn(Merged, "attr", {"Nature"}),

    // Same second pass as factRM: the material on its own, for rows the plant-qualified
    // key missed because the FG Master sheet has no valuation area or writes it differently.
    ByMat    = Table.Buffer(Table.Distinct(Table.SelectColumns(AttrSrc,
                   {"Material","Nature"}), {"Material"})),
    Second   = Table.NestedJoin(Expanded, {"Material"}, ByMat, {"Material"},
                   "attr2", JoinKind.LeftOuter),
    Both     = Table.ExpandTableColumn(Second, "attr2", {"Nature"}, {"Nature2"}),
    Coal     = Table.AddColumn(Both, "NatureX", each [Nature] ?? [Nature2], type text),
    Dropped  = Table.RemoveColumns(Coal, {"Nature","Nature2"}),
    Attr     = Table.RenameColumns(Dropped, {{"NatureX","Nature"}}),

    Flag     = Table.AddColumn(Attr, "AttrMissing", each [Nature] = null, type logical),
    // same as factRM: an FG whose technology the FG Master does not carry is called
    // Unassigned, so the technology matrix and the donut show it instead of a blank row
    Named    = Table.TransformColumns(Flag, {
                   {"Nature", each if _ = null or _ = "" then "Unassigned" else _, type text}}),

    // The last three digits of the material description. For a module they are its wattage
    // (580, 595); for a cell they are its efficiency in tenths of a percent (235 = 23.5%).
    RateTxt  = Table.AddColumn(Named, "RateText",
                   each Text.End(Text.Trim([MaterialDesc] ?? ""), 3), type text),
    RateNum  = Table.AddColumn(RateTxt, "RateRaw",
                   each try Number.From(Text.Select([RateText], {"0".."9","."})) otherwise null,
                   type number),

    // Mid = MID(desc,13,13)  -- M counts from 0, so the start is 12. On a cell this is the
    // wafer size, written "182.20x183.75".
    MidCol   = Table.AddColumn(RateNum, "Mid",
                   each try Text.Middle(Text.Trim([MaterialDesc] ?? ""), 12, 13) otherwise null,
                   type text),
    // Base = LEFT(Mid,6) - the first of the two dimensions, as a number
    BaseCol  = Table.AddColumn(MidCol, "Base",
                   each try Number.From(Text.Select(Text.Start([Mid], 6), {"0".."9","."}))
                        otherwise null, type number),

    // A module and a cell are rated differently, and the plant is what says which:
    //   1900, 1902 (modules):  Rate = RIGHT(description,3)                  -> about 580 W
    //   1905 (cells):          Rate = Base x Base x efficiency / 1000       -> about 7.8 W
    // Reading a cell's last three digits as its wattage is what put Dholera Cell's MW several
    // times too high: 235 W where the cell is 7.8 W. The efficiency is those same three digits
    // as a fraction (235 -> 0.235); a value already written as a fraction is left alone, so
    // either way of typing it comes out the same.
    Rate     = Table.AddColumn(BaseCol, "Rate",
                   each if [RateRaw] = null then null
                        else if Text.Trim(Text.From([ValuationArea] ?? "")) = "1905"
                        then (let Eff = if [RateRaw] > 1 then [RateRaw] / 1000 else [RateRaw] in
                              try [Base] * [Base] * Eff / 1000 otherwise null)
                        else [RateRaw],
                   type number),
    RateBad  = Table.AddColumn(Rate, "RateParseFailed",
                   each [Rate] = null, type logical),

    // MW = Closing Stock * Rate / 10^6
    MW       = Table.AddColumn(RateBad, "MW",
                   each try [CloseQty] * [Rate] / 1000000 otherwise null, type number),

    // Inr Wp = Closing Value / (MW * 10^6). A zero or missing MW is left blank rather than
    // divided by: dividing by zero in M produces NaN, which then prints as NaN in the report.
    INRwp    = Table.AddColumn(MW, "INR_WP",
                   each if [MW] = null or [MW] = 0 then null
                        else try [CloseVal] / ([MW] * 1000000) otherwise null, type number),

    Cleaned  = Table.RemoveColumns(INRwp, {"RateText", "RateRaw"})
in
    Cleaned
