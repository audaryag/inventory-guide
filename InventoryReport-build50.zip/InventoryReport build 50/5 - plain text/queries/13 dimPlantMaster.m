let
    Raw     = fnVarSheetSafe(
                  {"Plant Master", "PlantMaster", "Plants", "Plant"},
                  {
                    {{"Valuation Area","Val Area","Plant Code","Code","Plant"}, "ValuationArea"},
                    {{"Plant Name","Name","Description","Plant Description",
                      "Valuation Area Description"}, "PlantName"},
                    {{"Sort","Order","Sort Order"}, "PlantSort"},
                    {{"MWD","MW D","MWD (MW per day)","MW per Day","MW Day","MWPD",
                      "MW/Day","MW Per Day","Plant MWD","MWD Capacity","Capacity MWD",
                      "Daily MW","MW a Day"}, "PlantMWD"}
                  }),
    // The daily capacity column is the one thing on this sheet whose heading has been typed
    // several ways, so a heading the alias list missed is caught here: any remaining column
    // whose name carries "MWD" or "MW/D" is taken as it. Without this a heading like
    // "MWD (in MW)" reads as no capacity at all and every plant's days of cover goes blank.
    Norm    = (n as any) as text =>
                  Text.Upper(Text.Remove(Text.Trim(Text.From(n ?? "")),
                      {" ", ".", "_", "-", "/", "(", ")", ",", "'"})),
    Taken   = {"ValuationArea", "PlantName", "PlantSort", "PlantMWD"},
    Spare   = List.Select(Table.ColumnNames(Raw), each not List.Contains(Taken, _)),
    MWDName = List.First(List.Select(Spare, each Text.Contains(Norm(_), "MWD")), null),
    Found   = if List.Contains(Table.ColumnNames(Raw), "PlantMWD") or MWDName = null
              then Raw
              else Table.RenameColumns(Raw, {{MWDName, "PlantMWD"}}),
    Cols    = Taken,
    Padded  = List.Accumulate(List.Difference(Cols, Table.ColumnNames(Found)), Found,
                  (t, c) => Table.AddColumn(t, c, each null)),
    Slim    = Table.SelectColumns(Padded, Cols),
    // the code is text and trimmed, because 1900 read as a number will not join to a text key
    Keyed   = Table.TransformColumns(Slim, {
                  {"ValuationArea", each Text.Trim(Text.From(_ ?? "")), type text},
                  {"PlantName",     each Text.Trim(Text.From(_ ?? "")), type text}}),
    Real    = Table.SelectRows(Keyed, each [ValuationArea] <> ""),
    // the label the whole report shows: the code and the name together, so the slicer, the
    // legends and the ticker cards can never disagree about what a plant is called
    Label   = Table.AddColumn(Real, "Plant",
                  each if [PlantName] = "" then [ValuationArea]
                       else [ValuationArea] & " " & [PlantName], type text),
    Sorted  = Table.AddColumn(Label, "SortNo",
                  each try Number.From([PlantSort]) otherwise null, type number),
    Indexed = Table.AddIndexColumn(Sorted, "Seq", 1, 1, Int64.Type),
    Order   = Table.AddColumn(Indexed, "PlantSortNo",
                  each Int64.From([SortNo] ?? [Seq]), Int64.Type),
    // MWD - the plant's megawatts a day, typed on Plant Master. It is the denominator for
    // days of cover on the plant rows: days = inventory MW / MWD, nothing else divided in.
    // A figure typed as "3.6 MW", or with a comma in it, is still a figure: the digits are
    // taken and the rest ignored, because a denominator that will not parse shows as no days
    // of cover at all and reads on the page like missing stock.
    Rate    = Table.AddColumn(Order, "MWD",
                  each let t = Text.Trim(Text.From([PlantMWD] ?? "")),
                           v = try Number.From(t)
                               otherwise (try Number.From(
                                   Text.Select(t, {"0".."9","."})) otherwise null)
                       in  if v = null or v = 0 then null else v, type number),
    Out     = Table.SelectColumns(Rate, {"ValuationArea", "Plant", "PlantSortNo", "MWD"})
in
    Out
