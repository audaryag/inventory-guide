let
    // the month grid comes from the dated sheets, not from dimDate: referencing the calendar
    // here pulled the whole stock folder through this table too
    Months   = varMonthGrid,
    Combos   = Table.Distinct(Table.SelectColumns(varRMTechnologyCosts, {"PlantGroup","Item"})),
    Grid     = Table.AddColumn(Combos, "Month", each Months),
    Expanded = Table.ExpandListColumn(Grid, "Month"),
    AsOfCost = (g as text, i as text, m as date) as nullable number =>
                   let rows = Table.SelectRows(varRMTechnologyCosts, each
                                   [PlantGroup] = g and [Item] = i and [EffectiveFrom] <= m),
                       sorted = Table.Sort(rows, {{"EffectiveFrom", Order.Descending}})
                   in if Table.IsEmpty(sorted) then null else sorted{0}[CostINRWp],
    AsOfConst = (n as text, m as date) as nullable number =>
                   let rows = Table.SelectRows(varRMConstants, each
                                   [ConstantName] = n and [EffectiveFrom] <= m),
                       sorted = Table.Sort(rows, {{"EffectiveFrom", Order.Descending}})
                   in if Table.IsEmpty(sorted) then null else sorted{0}[Value],
    Cost     = Table.AddColumn(Expanded, "CostINRWp", each
                   AsOfCost([PlantGroup], [Item], Date.From([Month])), type number),
    Named    = Table.AddColumn(Cost, "ConstantName", each
                   if Text.Upper([PlantGroup]) = "CELL" then "Cell Production Constant"
                   else "Module Production Constant", type text),
    Constant = Table.AddColumn(Named, "ProductionConstant", each
                   AsOfConst([ConstantName], Date.From([Month])), type number),
    Daily    = Table.AddColumn(Constant, "PerDayCostCr", each
                   if [CostINRWp] = null or [ProductionConstant] = null then null
                   else [CostINRWp] * [ProductionConstant] / 10, type number),
    // the same spelling-proof key factInventory carries, so a component typed with a stray
    // space on one sheet still meets its inventory
    Key      = Table.AddColumn(Daily, "ItemKey",
                   each Text.Upper(Text.Remove(Text.Trim(Text.From([Item] ?? "")),
                       {" ",".","_","-","/","(",")",",","'"})), type text),
    Out      = Table.TransformColumnTypes(Table.SelectColumns(Key,
                   {"Month","PlantGroup","Item","ItemKey","CostINRWp","ProductionConstant",
                    "PerDayCostCr"}),
                   {{"Month", type date}, {"PlantGroup", type text}, {"Item", type text},
                    {"ItemKey", type text},
                    {"CostINRWp", type number}, {"ProductionConstant", type number},
                    {"PerDayCostCr", type number}})
in
    Out
