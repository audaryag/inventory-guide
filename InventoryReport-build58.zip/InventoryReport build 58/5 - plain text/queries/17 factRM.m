let
    Src      = stgRM,
    // The master sheet, read once and held. This query leans on it three times - on the
    // plant-and-material key, on the material alone, then on the description - and without
    // this line Power Query re-opens and re-parses the workbook for each of the three, because
    // a merge re-evaluates its right-hand side every time it is asked for.
    AttrSrc  = Table.Buffer(dimMaterialAttr),
    Merged   = Table.NestedJoin(Src, {"MatKey"}, AttrSrc, {"MatKey"},
                   "attr", JoinKind.LeftOuter),
    Expanded = Table.ExpandTableColumn(Merged, "attr",
                   {"Nature","GroupNature","BOMStdQty","Item"}),

    // Second pass on the material alone. Plant and material together is the safer key, but
    // it misses every row when the master sheet has no valuation area column, or records the
    // plant differently from the MB5B export -- and then nothing has a nature at all.
    ByMat    = Table.Buffer(Table.Distinct(Table.SelectColumns(AttrSrc,
                   {"Material","Nature","GroupNature","BOMStdQty","Item"}), {"Material"})),
    Second   = Table.NestedJoin(Expanded, {"Material"}, ByMat, {"Material"},
                   "attr2", JoinKind.LeftOuter),
    Both     = Table.ExpandTableColumn(Second, "attr2",
                   {"Nature","GroupNature","BOMStdQty","Item"},
                   {"Nature2","GroupNature2","BOMStdQty2","Item2"}),
    // Third pass on the material description, for a master sheet that lists its rows by
    // description rather than by number. It only ever fills a row the first two passes left
    // empty, so it cannot overwrite a proper match.
    DescK    = Table.AddColumn(Both, "DescKey",
                   each Text.Upper(Text.Trim(Text.From([MaterialDesc] ?? ""))), type text),
    ByDesc   = Table.Buffer(Table.Distinct(Table.SelectRows(Table.SelectColumns(AttrSrc,
                   {"DescKey","Nature","GroupNature","BOMStdQty","Item"}),
                   each [DescKey] <> null and [DescKey] <> ""), {"DescKey"})),
    Third    = Table.NestedJoin(DescK, {"DescKey"}, ByDesc, {"DescKey"},
                   "attr3", JoinKind.LeftOuter),
    All3     = Table.ExpandTableColumn(Third, "attr3",
                   {"Nature","GroupNature","BOMStdQty","Item"},
                   {"Nature3","GroupNature3","BOMStdQty3","Item3"}),
    Coal     = Table.AddColumn(All3, "NatureX",
                   each [Nature] ?? [Nature2] ?? [Nature3], type text),
    Coal2    = Table.AddColumn(Coal, "GroupNatureX",
                   each [GroupNature] ?? [GroupNature2] ?? [GroupNature3], type text),
    Coal3    = Table.AddColumn(Coal2, "BOMStdQtyX",
                   each [BOMStdQty] ?? [BOMStdQty2] ?? [BOMStdQty3], type number),
    Coal4    = Table.AddColumn(Coal3, "ItemX",
                   each [Item] ?? [Item2] ?? [Item3], type text),
    Dropped  = Table.RemoveColumns(Coal4, {"Nature","Nature2","Nature3",
                   "GroupNature","GroupNature2","GroupNature3",
                   "BOMStdQty","BOMStdQty2","BOMStdQty3","Item","Item2","Item3","DescKey"}),
    Attr     = Table.RenameColumns(Dropped, {{"NatureX","Nature"},
                   {"GroupNatureX","GroupNature"}, {"BOMStdQtyX","BOMStdQty"},
                   {"ItemX","Item"}}),

    Flag     = Table.AddColumn(Attr, "AttrMissing",
                   each [Nature] = null, type logical),
    // a row the master sheet does not cover is named rather than left null: a donut slice
    // reading Unassigned tells you there is work to do, one reading (Blank) tells you nothing
    Named    = Table.TransformColumns(Flag, {
                   {"Nature",      each if _ = null or _ = "" then "Unassigned" else _, type text},
                   {"GroupNature", each if _ = null or _ = "" then "Unassigned" else _, type text}}),
    // RM MW = Closing Stock / BOM Std Qty * RM_MW_FACTOR / 10^6
    // (the 580 you had hardcoded, now read from the Constants sheet)
    // The factor is looked up once per month rather than once per row - it can only change on a
    // dated Constants row, so every row of a month gets the same number either way - and joined
    // on. Asking for it per row scanned and sorted the Constants table tens of thousands of
    // times for an answer that was the same each time.
    Facs     = Table.Buffer(Table.AddColumn(
                   Table.Distinct(Table.SelectColumns(Named, {"Month"})), "MWFactor",
                   each fnConstantAsOf("RM_MW_FACTOR", [Month]), type number)),
    WithFac  = Table.ExpandTableColumn(
                   Table.NestedJoin(Named, {"Month"}, Facs, {"Month"}, "fac", JoinKind.LeftOuter),
                   "fac", {"MWFactor"}),
    MW       = Table.RemoveColumns(
                   Table.AddColumn(WithFac, "MW", each
                       try [CloseQty] / [BOMStdQty] * [MWFactor] / 1000000 otherwise null,
                       type number),
                   {"MWFactor"})
in
    MW
