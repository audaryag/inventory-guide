let
    Dates  = List.RemoveNulls(List.Combine({
                 try varMWCapacity[EffectiveFrom] otherwise {},
                 try varRMTechnologyCosts[EffectiveFrom] otherwise {},
                 try varRMPlantCosts[EffectiveFrom] otherwise {},
                 try varRMConstants[EffectiveFrom] otherwise {}})),
    First  = if List.IsEmpty(Dates) then Date.StartOfMonth(Date.From(DateTime.LocalNow()))
             else Date.StartOfMonth(List.Min(Dates)),
    Last   = Date.StartOfMonth(Date.AddMonths(Date.From(DateTime.LocalNow()), 18)),
    Span   = (Date.Year(Last) * 12 + Date.Month(Last))
             - (Date.Year(First) * 12 + Date.Month(First)),
    Months = if Span < 0 then {First}
             else List.Transform({0..Span}, (i) => Date.AddMonths(First, i)),
    Out    = List.Buffer(Months)
in
    Out
