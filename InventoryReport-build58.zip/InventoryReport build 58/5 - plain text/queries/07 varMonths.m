let
    Norm     = (n as any) as text =>
                   Text.Upper(Text.Remove(Text.Trim(Text.From(n ?? "")), {" ",".","_","-","/","(",")"})),
    // the header row is found in the first few dozen rows, so only those are materialised.
    // the rest of the sheet is read one column wide instead of twenty-nine.
    MonthsOf = (content as binary) as list =>
                   let
                       Wb       = Excel.Workbook(content, null, true),
                       Sheets   = Table.SelectRows(Wb, each [Kind] = "Sheet"),
                       Picked   = try Sheets{[Item = "Sheet1", Kind = "Sheet"]}[Data]
                                  otherwise Sheets{0}[Data],
                       Head     = Table.ToRows(Table.FirstN(Picked, 60)),
                       HdrIdx   = List.PositionOf(
                                      List.Transform(Head, (r) =>
                                          List.Contains(List.Transform(r, Norm), "MATERIAL")), true),
                       Skipped  = if HdrIdx > 0 then Table.Skip(Picked, HdrIdx) else Picked,
                       Promoted = Table.PromoteHeaders(Skipped, [PromoteAllScalars = true]),
                       Cols     = Table.ColumnNames(Promoted),
                       Pick     = (alts as list) as nullable text =>
                                      let Hits = List.Select(Cols, (c) => List.Contains(alts, Norm(c)))
                                      in  if List.IsEmpty(Hits) then null else List.First(Hits),
                       cFrom    = Pick({"FROMDATE"}),
                       cMat     = Pick({"MATERIAL","MATERIALNO"}),
                       Two      = if cFrom = null then null
                                  else Table.SelectColumns(Promoted,
                                           if cMat = null then {cFrom} else {cFrom, cMat}),
                       // a Total or subtotal line carries no material, and its stray date must
                       // not invent a month the facts do not have
                       Real     = if Two = null then null
                                  else if cMat = null then Two
                                  else Table.SelectRows(Two, each
                                           Text.Trim(Text.From(Record.Field(_, cMat) ?? "")) <> ""),
                       Dates    = if Real = null then {} else Table.Column(Real, cFrom),
                       Months   = List.RemoveNulls(List.Transform(Dates,
                                      (v) => try Date.StartOfMonth(Date.From(v)) otherwise null))
                   in
                       List.Distinct(Months),
    Stock    = (folder as text) as list =>
                   let
                       Files = try Folder.Files(pRoot & folder) otherwise #table({}, {}),
                       Only  = if Table.IsEmpty(Files) then Files
                               else Table.SelectRows(Files, each
                                        Text.StartsWith(Text.Lower([Extension]), ".xls")
                                        and not Text.StartsWith([Name], "~$")
                                        and not Text.StartsWith([Name], ".")),
                       Lists = if Table.IsEmpty(Only) then {}
                               else List.Transform(Only[Content], (c) => try MonthsOf(c) otherwise {})
                   in
                       List.Combine(Lists),
    // the trial balance's month is in its file name - TB_YYYYMM.xlsx - exactly as
    // factTB_Staged reads it, so those files are not opened here at all
    TBMonths = let
                   Files = try Folder.Files(pRoot & "\TB") otherwise #table({}, {}),
                   Only  = if Table.IsEmpty(Files) then Files
                           else Table.SelectRows(Files, each
                                    Text.StartsWith(Text.Lower([Extension]), ".xls")
                                    and not Text.StartsWith([Name], "~$")
                                    and not Text.StartsWith([Name], ".")),
                   Names = if Table.IsEmpty(Only) then {} else Only[Name],
                   Dates = List.Transform(Names, (n) =>
                               let digits = Text.Select(n, {"0".."9"}),
                                   yyyymm = Text.Middle(digits, 0, 6)
                               in  try #date(Number.From(Text.Start(yyyymm, 4)),
                                             Number.From(Text.Middle(yyyymm, 4, 2)), 1)
                                   otherwise null)
               in
                   List.RemoveNulls(Dates),
    All      = List.Combine({Stock("\RM Raw"), Stock("\FG Raw"), Stock("\Consble Raw"), TBMonths}),
    Out      = List.Buffer(List.Sort(List.Distinct(All)))
in
    Out
