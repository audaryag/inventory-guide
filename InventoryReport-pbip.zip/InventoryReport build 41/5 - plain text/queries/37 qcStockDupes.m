let
    Src     = Table.SelectRows(factInventory, each [RowsForMaterial] > 1),
    Slim    = Table.SelectColumns(Src, {
                  "Month", "ValuationArea", "Category", "Material", "MaterialDesc",
                  "RowsForMaterial", "CloseQty", "QtyNotUsed", "MW Qty", "CloseVal"}),
    Named   = Table.RenameColumns(Slim, {{"MW Qty", "MWValue"}}),
    RsCr    = Table.AddColumn(Named, "RsCr", each try [CloseVal] / 10000000 otherwise null,
                  type number),
    Out     = Table.RemoveColumns(RsCr, {"CloseVal"}),
    Sorted  = Table.Sort(Out, {{"QtyNotUsed", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"Month", type date}, {"ValuationArea", type text}, {"Category", type text},
                  {"Material", type text}, {"MaterialDesc", type text}})
in
    Typed
