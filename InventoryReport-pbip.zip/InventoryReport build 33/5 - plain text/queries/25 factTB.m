let
    // whitelisted by TB Master, and resolving to one of the three plants. No Unallocated:
    // a row whose profit centre names no plant is left out rather than parked on a plant that
    // does not exist, and qcTBPlants on Checks is where those rows are accounted for.
    Whole   = Table.SelectRows(factTB_Staged,
                  each [Whitelisted] = true and [ValuationArea] <> null),
    // SAP writes subtotal and result lines into the same column as the accounts. They carry
    // the sum of the lines above them, so leaving one in counts that money twice - which is
    // the classic reason a trial balance figure reads high without any single row being wrong.
    NoSums  = Table.SelectRows(Whole, each
                  let G = Text.Upper(Text.Trim(Text.From([GLAccount] ?? ""))),
                      D = Text.Upper(Text.From([GLDesc] ?? "")) in
                  G <> "" and not Text.Contains(G, "*")
                  and not Text.StartsWith(G, "TOTAL") and not Text.StartsWith(G, "RESULT")
                  and not Text.Contains(D, "RESULT")
                  and not Text.StartsWith(D, "TOTAL")),
    // the same line arriving twice is counted once, on the same rule the stock files use: two
    // rows are the same line when the month, the account, the profit centre and the amount all
    // agree. SourceFile is deliberately left out of that test, so one month exported twice into
    // the TB folder under two names cannot double the trial balance.
    Kept    = Table.Distinct(NoSums, {"Month", "GLAccount", "ProfitCentre", "Amount"}),
    // RM / FG / Consumables from whatever the Nature (or GL description) says
    // Raw material is tested BEFORE consumables, and that order matters: an account called
    // "Raw Material & Packing" holds the word PACK, so with consumables tested first the whole
    // of RM was filed under Consumables and the RM row vanished from Inventory (TB) while
    // Consumables read far too high. Packing on its own still lands in Consumables.
    // The Nature column on TB Master is the answer where it is filled - Consumables & Spares,
    // Raw Materials & Packing, Finished Goods - and the account description is read only when
    // that column is empty. Guessing from the description is what put Consumables on the FG
    // row: an account named for what it feeds is not an account named for what it holds.
    Bucket  = (n as any, d as any) as text =>
                  let N = Text.Trim(Text.From(n ?? "")),
                      T = Text.Upper(if N <> "" then N else Text.From(d ?? "")) in
                  if Text.Contains(T, "FINISH") or Text.Contains(T, "FG")
                      then "FG"
                  else if Text.Contains(T, "RAW") or Text.Contains(T, "RM")
                      or Text.Contains(T, "WIP") or Text.Contains(T, "SEMI")
                      then "RM"
                  else if Text.Contains(T, "CONSUM") or Text.Contains(T, "STORE")
                      or Text.Contains(T, "SPARE") or Text.Contains(T, "PACK")
                      then "Consumables"
                  else "RM",
    Cat     = Table.AddColumn(Kept, "Category",
                  each Bucket([Nature], [GLDesc]), type text),
    // exact column list and types, so the table is the same shape every refresh
    Wanted  = {"SourceFile","Month","GLAccount","GLDesc","ProfitCentre","ProfitCentreDesc",
               "Amount","PlantCode","ValuationArea","Nature","TBPlant","TBSort","Category"},
    Padded  = List.Accumulate(List.Difference(Wanted, Table.ColumnNames(Cat)), Cat,
                  (t, c) => Table.AddColumn(t, c, each null)),
    Slim    = Table.SelectColumns(Padded, Wanted),
    Typed   = Table.TransformColumnTypes(Slim, {
                  {"SourceFile", type text}, {"Month", type date},
                  {"GLAccount", type text}, {"GLDesc", type text},
                  {"ProfitCentre", type text}, {"ProfitCentreDesc", type text},
                  {"Amount", type number}, {"PlantCode", type text},
                  {"ValuationArea", type text}, {"Nature", type text},
                  {"TBPlant", type text}, {"TBSort", Int64.Type},
                  {"Category", type text}}),
    // the same flat plant-and-type key as factInventory, so one row of the Summary table can
    // hold the trial balance, the MB5B figure and the gap between them
    Keyed   = Table.AddColumn(Typed, "PlantType",
                  each Text.From([ValuationArea] ?? "") & "|" & Text.From([Category] ?? ""),
                  type text)
in
    Keyed
