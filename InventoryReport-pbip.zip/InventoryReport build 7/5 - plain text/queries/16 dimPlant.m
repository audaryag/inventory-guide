let
    Named    = #table(
        type table [ValuationArea = text, Plant = text, PlantSort = Int64.Type],
        {
            {"1900", "Jaipur Module",  1},
            {"1902", "Dholera Module", 2},
            {"1905", "Dholera Cell",   3},
            // factTB_Staged parks a profit centre it cannot place here
            {"Unallocated", "Unallocated", 98}
        }),
    // codes present in the stock files but not named above
    Seen     = List.Distinct(List.RemoveNulls(factInventory[ValuationArea])),
    Extra    = List.Difference(Seen, Named[ValuationArea]),
    ExtraT   = Table.FromRows(
                   List.Transform(Extra, (c) => {c, "Plant " & Text.From(c), 99}),
                   type table [ValuationArea = text, Plant = text, PlantSort = Int64.Type]),
    All      = Table.Combine({Named, ExtraT}),
    Dedup    = Table.Distinct(All, {"ValuationArea"})
in
    Dedup
