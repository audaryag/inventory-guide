let
    // The three plants and their names are decided here and nowhere else. Every page, slicer,
    // legend, card and row label reads this table, so no sheet and no page can call 1900
    // anything but Jaipur Module. Plant Master may still add a sort order; it is not allowed
    // to rename these three, because a swapped pair of rows in a spreadsheet renamed both
    // Jaipur and Dholera on every page at once.
    Fixed    = #table(
        type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type],
        {
            {"1900", "1900 Jaipur Module",  1},
            {"1902", "1902 Dholera Module", 2},
            {"1905", "1905 Dholera Cell",   3}
        }),
    Master   = try dimPlantMaster otherwise Fixed,
    Sheet    = if Table.IsEmpty(Master) then Fixed else Master,
    // the sheet's own sort order, taken by code and never by position
    WithSort = Table.AddColumn(Fixed, "SheetSort",
                   each let m = Table.SelectRows(Sheet, (r) => r[ValuationArea] = [ValuationArea])
                        in if Table.IsEmpty(m) then null
                           else try Int64.From(Table.First(m)[PlantSortNo]) otherwise null,
                   Int64.Type),
    Ordered  = Table.AddColumn(WithSort, "SortNo",
                   each [SheetSort] ?? [PlantSortNo], Int64.Type),
    // any plant the sheet lists that is not one of the three is still allowed through, named
    // as the sheet names it, so a fourth plant one day is not silently dropped
    Extra    = Table.SelectRows(Sheet,
                   each not List.Contains({"1900", "1902", "1905"}, [ValuationArea])),
    ExtraSet = Table.AddColumn(Extra, "SortNo",
                   each try Int64.From([PlantSortNo]) otherwise 99, Int64.Type),
    Named    = Table.Combine({
                   Table.SelectColumns(Ordered, {"ValuationArea", "Plant", "SortNo"}),
                   Table.SelectColumns(ExtraSet, {"ValuationArea", "Plant", "SortNo"})}),
    Renum    = Table.RenameColumns(Named, {{"SortNo", "PlantSortNo"}}),
    // codes present in the stock files or the trial balance. Only other queries are read
    // here and no folder is opened, which is what keeps the firewall quiet.
    Seen     = List.Distinct(List.RemoveNulls(
                   List.Combine({factInventory[ValuationArea], factTB_Staged[ValuationArea]}))),
    // a named plant with nothing behind it is left out, so the Plant slicer lists what the
    // files actually contain and not a fixed list padded with rows that pick nothing
    Live     = Table.SelectRows(Renum, each List.Contains(Seen, [ValuationArea])),
    Kept     = if Table.IsEmpty(Live) then Renum else Live,
    Dedup    = Table.Distinct(Kept, {"ValuationArea"}),
    Ren      = Table.RenameColumns(Dedup, {{"PlantSortNo", "PlantSort"}}),
    Typed    = Table.TransformColumnTypes(Ren, {
                   {"ValuationArea", type text}, {"Plant", type text},
                   {"PlantSort", Int64.Type}})
in
    Typed
