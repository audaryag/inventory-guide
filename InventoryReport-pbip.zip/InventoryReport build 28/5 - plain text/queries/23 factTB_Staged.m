let
    Norm     = (n as any) as text =>
                   Text.Upper(Text.Remove(Text.Trim(Text.From(n ?? "")), {" ",".","_","-","/","(",")"})),
    GLNames  = {"GLACCOUNTNUMBER","GLACCOUNT","GLACCOUNTNO","GLACCNO","ACCOUNTNUMBER","GLCODE"},
    Alias    = {
                   {GLNames, "GLAccount"},
                   {{"GLACCOUNTDESCRIPTION","GLACCOUNTDESC","ACCOUNTDESCRIPTION",
                     "GLDESCRIPTION","GLDESC","ACCOUNTNAME"}, "GLDesc"},
                   {{"PROFITCENTRE","PROFITCENTER","PROFITCTR","PRCTR"}, "ProfitCentre"},
                   {{"PROFITCENTREDESCRIPTION","PROFITCENTERDESCRIPTION",
                     "PROFITCENTREDESC","PROFITCENTERDESC"}, "ProfitCentreDesc"},
                   {{"AMOUNT","AMOUNTINLOCALCURRENCY","AMOUNTINLC","AMTINLOCCUR",
                     "BALANCE","CLOSINGBALANCE"}, "Amount"}
               },
    Wanted   = {"GLAccount","GLDesc","ProfitCentre","ProfitCentreDesc","Amount"},

    Clean    = (content as binary) as table =>
                   let
                       Wb       = Excel.Workbook(content, null, true),
                       Sheets   = Table.SelectRows(Wb, each [Kind] = "Sheet"),
                       Picked   = try Sheets{[Item = "Sheet1", Kind = "Sheet"]}[Data]
                                  otherwise Sheets{0}[Data],
                       // find the header row: the one holding a GL-account-ish cell
                       RowsL    = Table.ToRows(Picked),
                       HdrIdx   = List.PositionOf(
                                      List.Transform(RowsL, (r) =>
                                          List.AnyTrue(List.Transform(r,
                                              (c) => List.Contains(GLNames, Norm(c))))), true),
                       Skipped  = if HdrIdx <= 0 then Picked else Table.Skip(Picked, HdrIdx),
                       Promoted = Table.PromoteHeaders(Skipped, [PromoteAllScalars = true]),

                       Lookup   = (c as any) as nullable text =>
                                      let Hits = List.Select(Alias, (a) => List.Contains(a{0}, Norm(c)))
                                      in  if List.IsEmpty(Hits) then null else Hits{0}{1},
                       Pairs    = List.RemoveNulls(
                                      List.Transform(Table.ColumnNames(Promoted),
                                          (c) => let t = Lookup(c) in if t = null then null else {c, t})),
                       // if two source columns map to the same name, keep the first
                       Renames  = List.Accumulate(Pairs, {}, (acc, pr) =>
                                      if List.Contains(List.Transform(acc, (x) => x{1}), pr{1})
                                      then acc else acc & {pr}),
                       Renamed  = Table.RenameColumns(Promoted, Renames),
                       Padded   = List.Accumulate(
                                      List.Difference(Wanted, Table.ColumnNames(Renamed)), Renamed,
                                      (tbl, col) => Table.AddColumn(tbl, col, each null)),
                       Kept     = Table.SelectColumns(Padded, Wanted),
                       NoJunk   = Table.SelectRows(Kept, each
                                      [GLAccount] <> null
                                      and Text.Trim(Text.From([GLAccount])) <> ""
                                      and not Text.StartsWith(Text.From([GLAccount]), "Total",
                                              Comparer.OrdinalIgnoreCase))
                   in
                       NoJunk,

    Files    = Folder.Files(pRoot & "\TB"),
    OnlyXlsx = Table.SelectRows(Files, each
                   Text.StartsWith(Text.Lower([Extension]), ".xls")
                   and not Text.StartsWith([Name], "~$")
                   and not Text.StartsWith([Name], ".")),
    Loaded   = Table.AddColumn(OnlyXlsx, "Data", each Clean([Content])),

    // month from the file name: TB_YYYYMM.xlsx
    WithMonth = Table.AddColumn(Loaded, "Month", each
                   let
                       digits = Text.Select([Name], {"0".."9"}),
                       yyyymm = Text.Middle(digits, 0, 6)
                   in
                       try #date(Number.From(Text.Start(yyyymm, 4)),
                                 Number.From(Text.Middle(yyyymm, 4, 2)), 1)
                       otherwise null, type date),
    Slim     = Table.SelectColumns(WithMonth, {"Name","Month","Data"}),
    Expanded = Table.ExpandTableColumn(Slim, "Data", Wanted),
    Renamed  = Table.RenameColumns(Expanded, {{"Name","SourceFile"}}),
    Keys     = Table.TransformColumns(Renamed, {
                   {"GLAccount",    each Text.TrimStart(Text.Trim(Text.From(_ ?? "")), "0"), type text},
                   {"ProfitCentre", each Text.Trim(Text.From(_ ?? "")), type text}}),
    // the three named plant codes, written out here rather than read from dimPlant: a query
    // that opens a folder itself may not also reference another query, or the refresh stops
    // with 'references other queries or steps, so it may not directly access a data source'
    Known    = {"1900", "1902", "1905"},
    // The plant sat at characters 3-6 of the profit centre and nowhere else, so a profit
    // centre written to any other pattern lost its plant and the row was dropped - which is
    // how a whole plant went missing from Inventory (TB) while MB5B had it. Now: those four
    // characters first, then the first known code appearing anywhere in the profit centre,
    // then anywhere in its description. qcTBPlants on Checks shows what each one resolved to.
    Anywhere = (t as any) as nullable text =>
                   let Txt  = Text.From(t ?? ""),
                       Hits = List.Select(Known, each Text.Contains(Txt, _))
                   in  if List.IsEmpty(Hits) then null else Hits{0},
    // 1900 Jaipur Module, 1902 Dholera Module, 1905 Dholera Cell - the same three names the
    // whole report uses. A profit centre that spells the plant out instead of numbering it is
    // still a plant, and 1905 was being lost for exactly that reason: "Dholera Cell" carries
    // no 1905 anywhere in it.
    ByName   = (t as any) as nullable text =>
                   let T = Text.Upper(Text.From(t ?? "")) in
                   if Text.Contains(T, "JAIPUR") then "1900"
                   else if Text.Contains(T, "CELL") then "1905"
                   else if Text.Contains(T, "DHOLERA") then "1902"
                   else null,
    PlantRaw = Table.AddColumn(Keys, "PlantCode",
                   each try Text.Middle([ProfitCentre], 2, 4) otherwise null, type text),
    PlantCol = Table.AddColumn(PlantRaw, "ValuationArea",
                   each if List.Contains(Known, [PlantCode]) then [PlantCode]
                        else if Anywhere([ProfitCentre]) <> null then Anywhere([ProfitCentre])
                        else if Anywhere([ProfitCentreDesc]) <> null then Anywhere([ProfitCentreDesc])
                        else if ByName([ProfitCentreDesc]) <> null then ByName([ProfitCentreDesc])
                        else ByName([ProfitCentre]),
                   type text),
    // cell-by-cell, so an amount typed with a comma, a dash for nil, or a trailing CR/DR
    // cannot error the row and take the trial balance with it
    Typed    = Table.TransformColumns(PlantCol, {
                   {"Amount", each try Number.From(_)
                              otherwise try Number.From(Text.Select(Text.From(_ ?? ""),
                                             {"0".."9", ".", "-"}))
                              otherwise null, type number}}),

    // ---- the TB Master whitelist, read HERE and not in a later query -----------------------
    // Power Query's firewall forbids a query that references another query from also reaching
    // a data source, and it applies that test to the whole chain: factTB referencing both
    // factTB_Staged (which opens the TB folder) and dimTBMaster (which opens the workbook) is
    // exactly the combination it blocks, with 'references other queries or steps, so it may
    // not directly access a data source'. Doing the join in this query keeps both sources in
    // one place - a query may open as many sources as it likes as long as it leans on no other
    // query for data - so factTB and factTB_Unmapped below read nothing but this table.
    // fnVarSheet is a function, not data, so calling it here does not count as leaning.
    MasterRaw = try
                    fnVarSheet(
                        {"TB Master", "TBMaster", "TB"},
                        {
                          {{"GL Account Number","gl Account Number","GLAccountNumber",
                            "GL Account","G/L Account","GL No"},                  "GLAccount"},
                          {{"GL Account Description","GL Description","GLDescription",
                            "Account Description","Account Name"},                "GLDescMaster"},
                          {{"Nature","NaturePlant","Nature Plant"},               "Nature"},
                          {{"Plant","Valuation Area","NaturePlant2"},             "TBPlant"},
                          {{"Sort Order","SortOrder","Sort"},                      "TBSort"}
                        })
                otherwise #table({}, {}),
    MCols    = {"GLAccount","Nature","TBPlant","TBSort"},
    MPad     = List.Accumulate(List.Difference(MCols, Table.ColumnNames(MasterRaw)), MasterRaw,
                   (t, c) => Table.AddColumn(t, c, each null)),
    MKey     = Table.TransformColumns(MPad, {
                   {"GLAccount", each Text.TrimStart(Text.Trim(Text.From(_ ?? "")), "0"),
                    type text}}),
    MSort    = Table.TransformColumns(MKey, {
                   {"TBSort", each try Int64.From(Number.Round(Number.From(_))) otherwise null,
                    Int64.Type},
                   {"Nature",  each Text.Trim(Text.From(_ ?? "")), type text},
                   {"TBPlant", each Text.Trim(Text.From(_ ?? "")), type text}}),
    MReal    = Table.SelectRows(MSort, each [GLAccount] <> ""),
    // a plant code written on the master sheet itself, in the Plant column or inside the
    // NaturePlant text - the last resort when the profit centre carries no code at all
    // the GL account is the one key the trial balance and TB Master certainly share, so the
    // plant written against a GL on that sheet is read as a code (1905) or as a name
    // (Dholera Cell), in that order, on both of its columns
    MPlanted = Table.AddColumn(MReal, "MasterPlant",
                   each if Anywhere([TBPlant]) <> null then Anywhere([TBPlant])
                        else if Anywhere([Nature]) <> null then Anywhere([Nature])
                        else if ByName([TBPlant]) <> null then ByName([TBPlant])
                        else ByName([Nature]), type text),
    MKeep    = MCols & {"MasterPlant"},
    Master   = Table.Buffer(Table.Distinct(Table.SelectColumns(MPlanted, MKeep), {"GLAccount"})),
    Joined   = Table.NestedJoin(Typed, {"GLAccount"}, Master, {"GLAccount"},
                   "tpl", JoinKind.LeftOuter),
    Flagged  = Table.AddColumn(Joined, "Whitelisted",
                   each not Table.IsEmpty([tpl]), type logical),
    Widened  = Table.ExpandTableColumn(Flagged, "tpl",
                   {"Nature","TBPlant","TBSort","MasterPlant"}),
    // the master's plant is a last resort and only for a row that is a real posting: a line
    // with no profit centre at all is usually SAP's subtotal for the account above it, and
    // giving that a plant would count the same money twice
    Resolved = Table.AddColumn(Widened, "PlantResolved",
                   each if [ValuationArea] <> null then [ValuationArea]
                        else if Text.Trim(Text.From([ProfitCentre] ?? "")) = "" then null
                        else [MasterPlant], type text),
    Dropped  = Table.RemoveColumns(Resolved, {"ValuationArea"}),
    Renamed2 = Table.RenameColumns(Dropped, {{"PlantResolved", "ValuationArea"}}),
    // Rows that resolve to none of the three plants are kept HERE and left out in factTB, so
    // qcTBPlants can still see them: a plant going missing from Inventory (TB) has to be
    // visible somewhere, and a row silently dropped at this step is a row nobody can find.
    Out      = Table.TransformColumnTypes(Renamed2, {
                   {"Nature", type text}, {"TBPlant", type text}, {"TBSort", Int64.Type},
                   {"ValuationArea", type text}})
in
    Out
