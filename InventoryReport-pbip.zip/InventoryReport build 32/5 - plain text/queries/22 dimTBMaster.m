let
    Raw      = fnVarSheet(
                   {"TB Master", "TBMaster", "TB"},
                   {
                     {{"GL Account Number","gl Account Number","GLAccountNumber",
                       "GL Account","G/L Account","GL No"},                    "GLAccount"},
                     {{"GL Account Description","GL Description","GLDescription",
                       "Account Description","Account Name"},                  "GLDescMaster"},
                     {{"Nature","NaturePlant","Nature Plant"},                "Nature"},
                     {{"Plant","Valuation Area","NaturePlant2"},              "TBPlant"},
                     {{"Sort Order","SortOrder","Sort"},                       "TBSort"}
                   }),
    Keys     = Table.TransformColumns(Raw, {
                   {"GLAccount", each Text.TrimStart(Text.Trim(Text.From(_ ?? "")), "0"), type text}}),
    NoBlank  = Table.SelectRows(Keys, each [GLAccount] <> null and [GLAccount] <> ""),
    Wanted   = {"GLAccount","GLDescMaster","Nature","TBPlant","TBSort"},
    Present  = Table.ColumnNames(NoBlank),
    Padded   = List.Accumulate(List.Difference(Wanted, Present), NoBlank,
                   (t, c) => Table.AddColumn(t, c, each null)),
    Slim     = Table.SelectColumns(Padded, Wanted),
    // Master columns are converted one cell at a time with a fallback, never with a straight
    // type cast. A sort column holding 1.5, a blank, a dash or the word "last" is a typing
    // habit on a spreadsheet, not a mistake in the data - but Int64.Type on any of them raises
    // a row error, and Power BI then reports "Errors in dimTBMaster" and drops the whole
    // whitelist, which is how eight perfectly good GL accounts stopped being inventory.
    Sortable = Table.TransformColumns(Slim, {
                   {"TBSort", each try Int64.From(Number.Round(Number.From(_))) otherwise null,
                    Int64.Type}}),
    Texted   = Table.TransformColumns(Sortable, {
                   {"GLAccount",    each Text.From(_ ?? ""),  type text},
                   {"GLDescMaster", each Text.From(_ ?? ""),  type text},
                   {"Nature",       each Text.Trim(Text.From(_ ?? "")), type text},
                   {"TBPlant",      each Text.Trim(Text.From(_ ?? "")), type text}}),
    Dedup    = Table.Distinct(Texted, {"GLAccount"})
in
    Dedup
