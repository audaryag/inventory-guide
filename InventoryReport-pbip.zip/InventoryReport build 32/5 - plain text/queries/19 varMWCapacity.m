let
    Wb      = Excel.Workbook(File.Contents(pVarsFile), null, true),
    Sh      = Table.SelectRows(Wb, each [Kind] = "Sheet"),
    Norm    = (n as any) as text =>
                  Text.Upper(Text.Remove(Text.Trim(Text.From(n ?? "")), {" ",".","_","-","/","(",")"})),
    Hit     = Table.SelectRows(Sh, each
                  List.Contains({"MW","MWCAPACITY","CAPACITY","MWCAP"}, Norm([Item]))),
    Data    = if Table.IsEmpty(Hit)
                  then error "No sheet called MW / MW Capacity in the Variables workbook."
                  else Hit{0}[Data],
    Rows    = Table.ToRows(Data),
    Codes   = {"1900","1902","1905"},
    AsTxt   = (v as any) as text => Text.Trim(Text.From(v ?? "")),
    IsCode  = (v as any) as logical => List.Contains(Codes, AsTxt(v)),
    // a row that is the plant's whole capacity rather than one technology's. Written as
    // Total on the MW sheet - the March'26 | MW(S) block - and carried through as (All),
    // which is the name the days-of-cover measure looks for. It is not a nature and never
    // appears as one: dimNature drops it, so it cannot be sliced or drawn as a slice.
    TechName = (v as any) as text =>
                  let T = AsTxt(v) in
                  if List.Contains({"TOTAL","ALL","ALLPLANTS","PLANTTOTAL","TOTALPLANT",
                                    "GRANDTOTAL","MWS","CAPACITY","ALL"}, Norm(T))
                      then "(All)" else T,
    // a header cell that is a real date. A number is never taken for one: 1900 is a plant,
    // and Date.From would happily read it as a day in 1904.
    AsDate  = (v as any) as nullable date =>
                  if v = null then null
                  else if Value.Is(v, type date) then v
                  else if Value.Is(v, type datetime) then DateTime.Date(v)
                  else if Value.Is(v, type text) and (Text.Contains(v, "/") or Text.Contains(v, "-"))
                       then (try Date.From(v) otherwise null)
                  else null,

    // ---- decide which layout this sheet is -------------------------------------------------
    // long layout is identified by an Effective From header; wide layout by a row of plant codes
    DateHdr = {"EFFECTIVEFROM","EFFECTIVEDATE","FROMDATE"},
    LongIdx = List.PositionOf(
                  List.Transform(Rows, (r) =>
                      List.AnyTrue(List.Transform(r, (c) => List.Contains(DateHdr, Norm(c))))), true),
    WideIdx = List.PositionOf(
                  List.Transform(Rows, (r) => List.Count(List.Select(r, IsCode)) >= 2), true),
    // matrix layout: a header row carrying two or more real dates, plants down the side
    MtxIdx  = List.PositionOf(
                  List.Transform(Rows, (r) =>
                      List.Count(List.RemoveNulls(List.Transform(r, AsDate))) >= 2), true),

    // ---- long layout: one row per Tech per plant --------------------------------------------
    Long    = let
                  Hdr   = Rows{LongIdx},
                  Find  = (alts as list) as number =>
                              let Idxs = List.Select({0..List.Count(Hdr) - 1},
                                             (i) => List.Contains(alts, Norm(Hdr{i})))
                              in  if List.IsEmpty(Idxs) then -1 else List.First(Idxs),
                  iDate = Find({"EFFECTIVEFROM","EFFECTIVEDATE","FROMDATE","DATE"}),
                  iTech = Find({"TECH","TECHNOLOGY","NATURE"}),
                  iArea = Find({"VALUATIONAREA","VALAREA","PLANT","PLANTCODE"}),
                  iMW   = Find({"MW","CAPACITYMW","CAPACITY"}),
                  Chk   = if iTech < 0 or iArea < 0 or iMW < 0
                              then error "The MW sheet has an Effective From column but I could not "
                                       & "find Tech, Valuation Area and MW next to it. Read qcMWSheet."
                              else true,
                  Body  = if Chk then List.Skip(Rows, LongIdx + 1) else {},
                  Keep  = List.Select(Body, (r) =>
                              AsTxt(r{iTech}) <> "" and AsTxt(r{iArea}) <> ""),
                  Recs  = List.Transform(Keep, (r) =>
                              [ EffectiveFrom = (if iDate < 0 then #date(1900,1,1)
                                                 else try DateTime.Date(DateTime.From(r{iDate}))
                                                      otherwise #date(1900,1,1)),
                                Tech          = TechName(r{iTech}),
                                ValuationArea = AsTxt(r{iArea}),
                                MW            = (try Number.From(r{iMW}) otherwise 0) ])
              in  Recs,

    // ---- wide layout: plant codes across the top --------------------------------------------
    Wide    = let
                  Hdr   = Rows{WideIdx},
                  Map   = List.Select(
                              List.Transform({0..List.Count(Hdr) - 1},
                                  (i) => [Idx = i, Code = AsTxt(Hdr{i})]),
                              (m) => List.Contains(Codes, m[Code])),
                  Body  = List.Skip(Rows, WideIdx + 1),
                  Keep  = List.Select(Body, (r) =>
                              AsTxt(List.First(r)) <> "" and not IsCode(List.First(r))
                              and List.AnyTrue(List.Transform(Map,
                                  (m) => (try r{m[Idx]} otherwise null) <> null))),
                  Recs  = List.TransformMany(Keep, (r) => Map, (r, m) =>
                              [ EffectiveFrom = #date(1900,1,1),
                                Tech          = TechName(List.First(r)),
                                ValuationArea = m[Code],
                                MW            = (try Number.From(r{m[Idx]}) otherwise 0) ])
              in  Recs,

    // ---- matrix layout: a month per column, a plant per row ---------------------------------
    // the layout to keep the sheet in. Each date column is an effective-from, so the figure
    // stands until a later column changes it and a month with no column of its own is not a
    // hole. A blank cell is not nought: nought capacity would wipe out the figure before it.
    Matrix  = let
                  Hdr    = Rows{MtxIdx},
                  Cols   = List.Select(
                               List.Transform({0..List.Count(Hdr) - 1},
                                   (i) => [Idx = i, D = AsDate(Hdr{i})]),
                               (m) => m[D] <> null),
                  DIdx   = List.Transform(Cols, each _[Idx]),
                  Body   = List.Skip(Rows, MtxIdx + 1),
                  Other  = List.Select({0..List.Count(Hdr) - 1}, (i) => not List.Contains(DIdx, i)),
                  // the plant column is whichever of the remaining columns holds the codes
                  Score  = List.Transform(Other, (i) =>
                               [ Idx = i,
                                 N   = List.Count(List.Select(Body,
                                           (r) => IsCode(try r{i} otherwise null))) ]),
                  Best   = List.Last(List.Sort(Score, (a, b) => Value.Compare(a[N], b[N])), null),
                  iArea  = if Best = null or Best[N] = 0 then -1 else Best[Idx],
                  Chk    = if iArea < 0
                               then error "The MW sheet has month columns but no column of plant "
                                        & "codes (1900 / 1902 / 1905) beside them. Read qcMWSheet."
                               else true,
                  // a technology column is optional: the first other column that carries text
                  Named  = List.Select(Other, (i) =>
                               i <> iArea and List.AnyTrue(List.Transform(Body,
                                   (r) => AsTxt(try r{i} otherwise null) <> ""
                                          and not IsCode(try r{i} otherwise null)))),
                  iTech  = if not Chk or List.IsEmpty(Named) then -1 else List.First(Named),
                  Keep   = if Chk then List.Select(Body, (r) => IsCode(try r{iArea} otherwise null))
                           else {},
                  Cells  = List.TransformMany(Keep, (r) => Cols, (r, c) =>
                               [ EffectiveFrom = c[D],
                                 Tech          = if iTech < 0 or AsTxt(try r{iTech} otherwise null) = ""
                                                 then "(All)" else TechName(r{iTech}),
                                 ValuationArea = AsTxt(r{iArea}),
                                 Raw           = (try r{c[Idx]} otherwise null) ]),
                  Filled = List.Select(Cells, (x) => AsTxt(x[Raw]) <> ""),
                  Recs   = List.Transform(Filled, (x) =>
                               [ EffectiveFrom = x[EffectiveFrom],
                                 Tech          = x[Tech],
                                 ValuationArea = x[ValuationArea],
                                 MW            = (if AsTxt(x[Raw]) = "-" then 0
                                                  else try Number.From(x[Raw]) otherwise 0) ])
              in  Recs,

    Pairs   = if LongIdx >= 0 then Long
              else if MtxIdx >= 0 then Matrix
              else if WideIdx >= 0 then Wide
              else error "The MW sheet is none of the three layouts I recognise: no Effective "
                       & "From/Tech header row, no row of month dates over a column of plant "
                       & "codes, and no row containing two of 1900/1902/1905. Read qcMWSheet.",
    T       = Table.FromRecords(Pairs,
                  type table [EffectiveFrom = date, Tech = text, ValuationArea = text, MW = number]),
    Out     = Table.Buffer(T)
in
    Out
