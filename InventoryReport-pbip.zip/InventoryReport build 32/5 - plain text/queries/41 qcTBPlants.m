let
    Src     = factTB_Staged,
    Named   = Table.TransformColumns(Src, {
                  {"ProfitCentre", each if Text.From(_ ?? "") = "" then "(blank)" else _,
                   type text}}),
    Grouped = Table.Group(Named, {"ProfitCentre"}, {
                  {"Description", each Text.From(List.First([ProfitCentreDesc]) ?? ""), type text},
                  {"PlantResolved", each Text.Combine(
                                        List.Transform(List.Distinct([ValuationArea]),
                                            each Text.From(_ ?? "(none)")), " | "), type text},
                  {"Rows", each Table.RowCount(_), Int64.Type},
                  {"InventoryRows", each List.Count(List.Select([Whitelisted], each _ = true)),
                   Int64.Type},
                  {"AmountRsCr", each List.Sum(List.Transform([Amount], each _ ?? 0)) / 10000000,
                   type number}}),
    Sorted  = Table.Sort(Grouped, {{"PlantResolved", Order.Ascending},
                                   {"AmountRsCr", Order.Descending}})
in
    Sorted
