let
    Norm     = (n as any) as text =>
                   Text.Upper(Text.Remove(Text.Trim(Text.From(n ?? "")), {" ",".","_","-","/","(",")"})),
    GLNames  = {"GLACCOUNTNUMBER","GLACCOUNT","GLACCOUNTNO","GLACCNO","ACCOUNTNUMBER","GLCODE"},
    Alias    = {
                   {GLNames, "GLAccount"},
                   {{"GLACCOUNTDESCRIPTION","GLACCOUNTDESC","ACCOUNTDESCRIPTION",
                     "GLDESCRIPTION","GLDESC","ACCOUNTNAME"}, "GLDesc"},
                   {{"PROFITCENTRE","PROFITCENTER","PROFITCTR","PRCTR"}, "ProfitCentre"},
                   {{"PROFITCENTREDESCRIPTION","PROFITCENTERDESCRIPTION",
                     "PROFITCENTREDESC","PROFITCENTERDESC"}, "ProfitCentreDesc"},
                   {{"AMOUNT","AMOUNTINLOCALCURRENCY","AMOUNTINLC","AMTINLOCCUR",
                     "BALANCE","CLOSINGBALANCE"}, "Amount"}
               },
    Wanted   = {"GLAccount","GLDesc","ProfitCentre","ProfitCentreDesc","Amount"},

    Clean    = (content as binary) as table =>
                   let
                       Wb       = Excel.Workbook(content, null, true),
                       Sheets   = Table.SelectRows(Wb, each [Kind] = "Sheet"),
                       Picked   = try Sheets{[Item = "Sheet1", Kind = "Sheet"]}[Data]
                                  otherwise Sheets{0}[Data],
                       // find the header row: the one holding a GL-account-ish cell
                       RowsL    = Table.ToRows(Picked),
                       HdrIdx   = List.PositionOf(
                                      List.Transform(RowsL, (r) =>
                                          List.AnyTrue(List.Transform(r,
                                              (c) => List.Contains(GLNames, Norm(c))))), true),
                       Skipped  = if HdrIdx <= 0 then Picked else Table.Skip(Picked, HdrIdx),
                       Promoted = Table.PromoteHeaders(Skipped, [PromoteAllScalars = true]),

                       Lookup   = (c as any) as nullable text =>
                                      let Hits = List.Select(Alias, (a) => List.Contains(a{0}, Norm(c)))
                                      in  if List.IsEmpty(Hits) then null else Hits{0}{1},
                       Pairs    = List.RemoveNulls(
                                      List.Transform(Table.ColumnNames(Promoted),
                                          (c) => let t = Lookup(c) in if t = null then null else {c, t})),
                       // if two source columns map to the same name, keep the first
                       Renames  = List.Accumulate(Pairs, {}, (acc, pr) =>
                                      if List.Contains(List.Transform(acc, (x) => x{1}), pr{1})
                                      then acc else acc & {pr}),
                       Renamed  = Table.RenameColumns(Promoted, Renames),
                       Padded   = List.Accumulate(
                                      List.Difference(Wanted, Table.ColumnNames(Renamed)), Renamed,
                                      (tbl, col) => Table.AddColumn(tbl, col, each null)),
                       Kept     = Table.SelectColumns(Padded, Wanted),
                       NoJunk   = Table.SelectRows(Kept, each
                                      [GLAccount] <> null
                                      and Text.Trim(Text.From([GLAccount])) <> ""
                                      and not Text.StartsWith(Text.From([GLAccount]), "Total",
                                              Comparer.OrdinalIgnoreCase))
                   in
                       NoJunk,

    Files    = Folder.Files(pRoot & "\TB"),
    OnlyXlsx = Table.SelectRows(Files, each
                   Text.StartsWith(Text.Lower([Extension]), ".xls")
                   and not Text.StartsWith([Name], "~$")
                   and not Text.StartsWith([Name], ".")),
    Loaded   = Table.AddColumn(OnlyXlsx, "Data", each Clean([Content])),

    // month from the file name: TB_YYYYMM.xlsx
    WithMonth = Table.AddColumn(Loaded, "Month", each
                   let
                       digits = Text.Select([Name], {"0".."9"}),
                       yyyymm = Text.Middle(digits, 0, 6)
                   in
                       try #date(Number.From(Text.Start(yyyymm, 4)),
                                 Number.From(Text.Middle(yyyymm, 4, 2)), 1)
                       otherwise null, type date),
    Slim     = Table.SelectColumns(WithMonth, {"Name","Month","Data"}),
    Expanded = Table.ExpandTableColumn(Slim, "Data", Wanted),
    Renamed  = Table.RenameColumns(Expanded, {{"Name","SourceFile"}}),
    // One normalisation for both keys and both sides, and it has to survive everything Excel
    // and SAP do to a code that is really just a number. The export writes a profit centre
    // with two leading zeros that the sheet does not have; one file holds it as text and the
    // other as a number, so 1902001 arrives as "1902001", "001902001", "1902001.0" or with a
    // space or a hyphen inside it. So: take the digits and letters, drop everything else,
    // upper-case it, and drop leading zeros. All of those then come out as 1902001, and a
    // code that is genuinely different still is.
    KeyOf    = (v as any) as text =>
                   let T = Text.Trim(Text.From(v ?? "")),
                       // a code has no fraction: 1902001.0 is Excel's doing, not SAP's
                       D = if Text.Contains(T, ".") then Text.Start(T, Text.PositionOf(T, ".")) else T,
                       K = Text.Upper(Text.Select(D, {"0".."9", "a".."z", "A".."Z"})),
                       Z = Text.TrimStart(K, "0")
                   in  if Z = "" then K else Z,
    Keys     = Table.AddColumn(
                   Table.TransformColumns(Renamed, {
                       {"GLAccount",    each KeyOf(_), type text},
                       {"ProfitCentre", each Text.Trim(Text.From(_ ?? "")), type text}}),
                   "PCKey", each KeyOf([ProfitCentre]), type text),
    // the three named plant codes, written out here rather than read from dimPlant: a query
    // that opens a folder itself may not also reference another query, or the refresh stops
    // with 'references other queries or steps, so it may not directly access a data source'
    Known    = {"1900", "1902", "1905"},
    // The plant sat at characters 3-6 of the profit centre and nowhere else, so a profit
    // centre written to any other pattern lost its plant and the row was dropped - which is
    // how a whole plant went missing from Inventory (TB) while MB5B had it. Now: those four
    // characters first, then the first known code appearing anywhere in the profit centre,
    // then anywhere in its description. qcTBPlants on Checks shows what each one resolved to.
    Anywhere = (t as any) as nullable text =>
                   let Txt  = Text.From(t ?? ""),
                       Hits = List.Select(Known, each Text.Contains(Txt, _))
                   in  if List.IsEmpty(Hits) then null else Hits{0},
    // 1902 Jaipur Module, 1900 Dholera Module, 1905 Dholera Cell - the same three names the
    // whole report uses, and the codes as the Summary workbook has them. A profit centre that
    // spells the plant out instead of numbering it is still a plant, and 1905 was being lost
    // for exactly that reason: "Dholera Cell" carries no 1905 anywhere in it. Cell is tested
    // before Dholera, because Dholera Cell contains both words.
    ByName   = (t as any) as nullable text =>
                   let T = Text.Upper(Text.From(t ?? "")) in
                   if Text.Contains(T, "JAIPUR") then "1902"
                   else if Text.Contains(T, "CELL") then "1905"
                   else if Text.Contains(T, "DHOLERA") then "1900"
                   else null,
    PlantRaw = Table.AddColumn(Keys, "PlantCode",
                   each try Text.Middle([ProfitCentre], 2, 4) otherwise null, type text),
    PlantCol = Table.AddColumn(PlantRaw, "ValuationArea",
                   each if List.Contains(Known, [PlantCode]) then [PlantCode]
                        else if Anywhere([ProfitCentre]) <> null then Anywhere([ProfitCentre])
                        else if Anywhere([ProfitCentreDesc]) <> null then Anywhere([ProfitCentreDesc])
                        else if ByName([ProfitCentreDesc]) <> null then ByName([ProfitCentreDesc])
                        else ByName([ProfitCentre]),
                   type text),
    // cell-by-cell, so an amount typed with a comma, a dash for nil, or a trailing CR/DR
    // cannot error the row and take the trial balance with it
    Typed    = Table.TransformColumns(PlantCol, {
                   {"Amount", each try Number.From(_)
                              otherwise try Number.From(Text.Select(Text.From(_ ?? ""),
                                             {"0".."9", ".", "-"}))
                              otherwise null, type number}}),

    // ---- the TB Master whitelist, read HERE and not in a later query -----------------------
    // Power Query's firewall forbids a query that references another query from also reaching
    // a data source, and it applies that test to the whole chain: factTB referencing both
    // factTB_Staged (which opens the TB folder) and dimTBMaster (which opens the workbook) is
    // exactly the combination it blocks, with 'references other queries or steps, so it may
    // not directly access a data source'. Doing the join in this query keeps both sources in
    // one place - a query may open as many sources as it likes as long as it leans on no other
    // query for data - so factTB and factTB_Unmapped below read nothing but this table.
    // fnVarSheet is a function, not data, so calling it here does not count as leaning.
    MasterRaw = try
                    fnVarSheet(
                        {"TB Master", "TBMaster", "TB"},
                        {
                          {{"GL Account Number","gl Account Number","GLAccountNumber",
                            "GL Account","G/L Account","GL No"},                  "GLAccount"},
                          {{"GL Account Description","GL Description","GLDescription",
                            "Account Description","Account Name"},                "GLDescMaster"},
                          {{"Nature","NaturePlant","Nature Plant"},               "Nature"},
                          {{"Plant","Valuation Area","NaturePlant2"},             "TBPlant"},
                          {{"Sort Order","SortOrder","Sort"},                      "TBSort"},
                          {{"Profit Center","Profit Centre","ProfitCenter","ProfitCentre",
                            "Profit Ctr","PRCTR"},                                  "MPC"}
                        })
                otherwise #table({}, {}),
    MCols    = {"GLAccount","PCKey","Nature","TBPlant","TBSort"},
    MPad     = List.Accumulate(
                   List.Difference({"GLAccount","MPC","Nature","TBPlant","TBSort"},
                       Table.ColumnNames(MasterRaw)),
                   MasterRaw, (t, c) => Table.AddColumn(t, c, each null)),
    // Both keys normalised the same way on both sides, so a code typed as a number in one
    // file and as text in the other still matches: 0000123400 and 123400 and 123400.0 all
    // come out as 123400.
    MKey     = Table.AddColumn(
                   Table.TransformColumns(MPad, {
                       {"GLAccount", each KeyOf(_), type text}}),
                   "PCKey", each KeyOf([MPC]), type text),
    MSort    = Table.TransformColumns(MKey, {
                   {"TBSort", each try Int64.From(Number.Round(Number.From(_))) otherwise null,
                    Int64.Type},
                   {"Nature",  each Text.Trim(Text.From(_ ?? "")), type text},
                   {"TBPlant", each Text.Trim(Text.From(_ ?? "")), type text}}),
    MReal    = Table.SelectRows(MSort, each [GLAccount] <> ""),
    // a plant code written on the master sheet itself, in the Plant column or inside the
    // NaturePlant text - the last resort when the profit centre carries no code at all
    // the GL account is the one key the trial balance and TB Master certainly share, so the
    // plant written against a GL on that sheet is read as a code (1905) or as a name
    // (Dholera Cell), in that order, on both of its columns
    MPlanted = Table.AddColumn(MReal, "MasterPlant",
                   each if Anywhere([TBPlant]) <> null then Anywhere([TBPlant])
                        else if Anywhere([Nature]) <> null then Anywhere([Nature])
                        else if ByName([TBPlant]) <> null then ByName([TBPlant])
                        else ByName([Nature]), type text),
    // The GL account alone cannot name a plant: TB Master lists the same GL against all three
    // plants, so on its own it is a whitelist and nothing more. The pair - GL account AND
    // profit centre - is what identifies one row of that sheet, and only then do its Plant,
    // Nature and Sort belong to the trial-balance line. That pair is the report's answer for
    // every trial-balance figure on every page.
    // A pair is only an answer if the sheet is unanimous about it. Where the same GL account
    // and profit centre appear on TB Master twice with different Plants, the join used to
    // take whichever row it met first - which put some accounts on the wrong plant and left
    // others right, scattered rather than swapped, and no way to see it had happened. Those
    // pairs are held back here: they resolve to nothing, they are counted nowhere, and
    // qcTBUnmatched names them with 'two plants on TB Master for this pair'.
    MGroup   = Table.Group(MPlanted, {"GLAccount", "PCKey"}, {
                   {"Plants",  each List.Distinct(List.Select(List.Transform([TBPlant],
                                   each Text.Trim(Text.From(_ ?? ""))), each _ <> "")), type list},
                   {"Natures", each List.Distinct(List.Select(List.Transform([Nature],
                                   each Text.Trim(Text.From(_ ?? ""))), each _ <> "")), type list},
                   {"Rows",    each Table.RowCount(_), Int64.Type}}),
    MAmbig   = Table.SelectRows(MGroup, each List.Count([Plants]) > 1),
    MClean   = Table.SelectRows(MGroup, each List.Count([Plants]) <= 1),
    MasterPair = Table.Buffer(
                     Table.NestedJoin(
                         Table.Distinct(Table.SelectColumns(MPlanted, MCols),
                             {"GLAccount", "PCKey"}),
                         {"GLAccount","PCKey"},
                         Table.SelectColumns(MClean, {"GLAccount","PCKey"}), {"GLAccount","PCKey"},
                         "ok", JoinKind.Inner)),
    // the ambiguous pairs, kept so the report can say why a line went nowhere
    AmbigKeys = Table.Buffer(Table.AddColumn(
                    Table.SelectColumns(MAmbig, {"GLAccount","PCKey","Plants"}),
                    "AmbigPlants", each Text.Combine([Plants], " / "), type text)),
    Joined   = Table.NestedJoin(Typed, {"GLAccount","PCKey"}, MasterPair, {"GLAccount","PCKey"},
                   "tpl", JoinKind.LeftOuter),
    Joined2  = Table.NestedJoin(Joined, {"GLAccount"}, MasterGL, {"GLAccount"},
                   "tgl", JoinKind.LeftOuter),
    Joined3  = Table.NestedJoin(Joined2, {"GLAccount","PCKey"},
                   Table.SelectColumns(AmbigKeys, {"GLAccount","PCKey","AmbigPlants"}),
                   {"GLAccount","PCKey"}, "tam", JoinKind.LeftOuter),
    // an inventory account is one the sheet lists at all; whether its plant is known is a
    // separate question, answered by PairMatched below
    Flagged  = Table.AddColumn(Joined3, "Whitelisted",
                   each not Table.IsEmpty([tgl]), type logical),
    Paired   = Table.AddColumn(Flagged, "PairMatched",
                   each not Table.IsEmpty([tpl]), type logical),
    Widened  = Table.ExpandTableColumn(
                   Table.ExpandTableColumn(
                       Table.ExpandTableColumn(Paired, "tpl", {"Nature","TBPlant","TBSort"}),
                       "tgl", {"GLNature","GLTBSort"}),
                   "tam", {"AmbigPlants"}),
    // the nature is the matched row's, and where the pair has no row yet the GL's own nature
    // stands in - so Consumables & Spares is never guessed at from the account name
    Natured  = Table.AddColumn(Widened, "NatureUse",
                   each if Text.Trim(Text.From([Nature] ?? "")) <> "" then [Nature]
                        else [GLNature], type text),
    // The plant is the matched pair's Plant column, read as a code or as a plant name, and
    // there is no second rule. Reading it from the profit centre as well made two rules run
    // at once, and a row the sheet had not reached yet was placed by the old guess instead of
    // standing out - which moved the figures further off, not closer. A pair with no row on
    // TB Master now resolves to nothing, is left out of every trial-balance figure, and is
    // listed by qcTBUnmatched with what it is worth. That list is finite: type those pairs
    // onto the sheet and the trial balance is right by construction.
    Resolved = Table.AddColumn(Natured, "PlantResolved",
                   each if Anywhere([TBPlant]) <> null then Anywhere([TBPlant])
                        else ByName([TBPlant]), type text),
    Dropped  = Table.RemoveColumns(Resolved, {"ValuationArea"}),
    Renamed2 = Table.RenameColumns(Dropped, {{"PlantResolved", "ValuationArea"}}),
    // Rows that resolve to none of the three plants are kept HERE and left out in factTB, so
    // qcTBPlants can still see them: a plant going missing from Inventory (TB) has to be
    // visible somewhere, and a row silently dropped at this step is a row nobody can find.
    Natured2 = Table.RemoveColumns(
                   Table.RenameColumns(
                       Table.RemoveColumns(Renamed2, {"Nature"}),
                       {{"NatureUse", "Nature"}}),
                   {"GLNature", "GLTBSort"}),
    Out      = Table.TransformColumnTypes(Natured2, {
                   {"Nature", type text}, {"TBPlant", type text}, {"TBSort", Int64.Type},
                   {"ValuationArea", type text}})
in
    Out
