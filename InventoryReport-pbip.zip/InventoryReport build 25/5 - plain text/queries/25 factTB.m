let
    // whitelisted by TB Master, and resolving to one of the three plants. No Unallocated:
    // a row whose profit centre names no plant is left out rather than parked on a plant that
    // does not exist, and qcTBPlants on Checks is where those rows are accounted for.
    Kept    = Table.SelectRows(factTB_Staged,
                  each [Whitelisted] = true and [ValuationArea] <> null),
    // RM / FG / Consumables from whatever the Nature (or GL description) says
    // Raw material is tested BEFORE consumables, and that order matters: an account called
    // "Raw Material & Packing" holds the word PACK, so with consumables tested first the whole
    // of RM was filed under Consumables and the RM row vanished from Inventory (TB) while
    // Consumables read far too high. Packing on its own still lands in Consumables.
    Bucket  = (n as any, d as any) as text =>
                  let T = Text.Upper(Text.From(n ?? "") & " " & Text.From(d ?? "")) in
                  if Text.Contains(T, "FINISH") or Text.Contains(T, "FG")
                      then "FG"
                  else if Text.Contains(T, "RAW") or Text.Contains(T, "RM")
                      or Text.Contains(T, "WIP") or Text.Contains(T, "SEMI")
                      then "RM"
                  else if Text.Contains(T, "CONSUM") or Text.Contains(T, "STORE")
                      or Text.Contains(T, "SPARE") or Text.Contains(T, "PACK")
                      then "Consumables"
                  else "RM",
    Cat     = Table.AddColumn(Kept, "Category",
                  each Bucket([Nature], [GLDesc]), type text),
    // exact column list and types, so the table is the same shape every refresh
    Wanted  = {"SourceFile","Month","GLAccount","GLDesc","ProfitCentre","ProfitCentreDesc",
               "Amount","PlantCode","ValuationArea","Nature","TBPlant","TBSort","Category"},
    Padded  = List.Accumulate(List.Difference(Wanted, Table.ColumnNames(Cat)), Cat,
                  (t, c) => Table.AddColumn(t, c, each null)),
    Slim    = Table.SelectColumns(Padded, Wanted),
    Typed   = Table.TransformColumnTypes(Slim, {
                  {"SourceFile", type text}, {"Month", type date},
                  {"GLAccount", type text}, {"GLDesc", type text},
                  {"ProfitCentre", type text}, {"ProfitCentreDesc", type text},
                  {"Amount", type number}, {"PlantCode", type text},
                  {"ValuationArea", type text}, {"Nature", type text},
                  {"TBPlant", type text}, {"TBSort", Int64.Type},
                  {"Category", type text}})
in
    Typed
