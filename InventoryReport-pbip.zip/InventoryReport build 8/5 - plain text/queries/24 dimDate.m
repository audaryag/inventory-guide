let
    MinD   = Date.StartOfMonth(List.Min(factInventory[Month])),
    MaxD   = Date.StartOfMonth(List.Max(factInventory[Month])),
    Start  = #date(Date.Year(MinD) - (if Date.Month(MinD) < 4 then 1 else 0), 4, 1),
    Count  = (Date.Year(MaxD) * 12 + Date.Month(MaxD))
             - (Date.Year(Start) * 12 + Date.Month(Start)) + 1,
    Months = List.Transform({0..Count - 1}, (i) => Date.AddMonths(Start, i)),
    T      = Table.TransformColumnTypes(
                 Table.FromList(Months, Splitter.SplitByNothing(), {"Month"}),
                 {{"Month", type date}}),
    MN     = Table.AddColumn(T, "MonthName", each Date.ToText([Month], "MMM''yy"), type text),
    MS     = Table.AddColumn(MN, "MonthSort",
                 each Date.Year([Month]) * 100 + Date.Month([Month]), Int64.Type),
    MI     = Table.AddColumn(MS, "MonthIndex",
                 each Date.Year([Month]) * 12 + Date.Month([Month]), Int64.Type),
    FY     = Table.AddColumn(MI, "FY", each
                 let y = if Date.Month([Month]) >= 4 then Date.Year([Month]) else Date.Year([Month]) - 1
                 in  "FY " & Text.From(y) & "-" & Text.End(Text.From(y + 1), 2), type text),
    // the year starts on 1 April, so Apr-Jun is Q1 and Jan-Mar is Q4
    FYMonth = Table.AddColumn(FY, "FYMonthNo",
                 each Number.Mod(Date.Month([Month]) - 4, 12) + 1, Int64.Type),
    Qtr    = Table.AddColumn(FYMonth, "QuarterNo",
                 each Number.RoundUp([FYMonthNo] / 3), Int64.Type),
    QName  = Table.AddColumn(Qtr, "Quarter",
                 each "Q" & Text.From([QuarterNo]) & " " & [FY], type text),
    QSort  = Table.AddColumn(QName, "QuarterSort", each
                 let y = if Date.Month([Month]) >= 4 then Date.Year([Month]) else Date.Year([Month]) - 1
                 in  y * 10 + [QuarterNo], Int64.Type),
    Out    = Table.SelectColumns(QSort,
                 {"Month","MonthName","MonthSort","MonthIndex","FY",
                  "FYMonthNo","QuarterNo","Quarter","QuarterSort"})
in
    Out
