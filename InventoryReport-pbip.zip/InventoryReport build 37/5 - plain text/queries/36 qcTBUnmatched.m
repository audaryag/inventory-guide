let
    Src     = Table.SelectRows(factTB_Staged, each [PairMatched] = false),
    Named   = Table.TransformColumns(Src, {
                  {"ProfitCentre", each if Text.From(_ ?? "") = "" then "(blank)" else _,
                   type text}}),
    Grouped = Table.Group(Named, {"GLAccount", "ProfitCentre"}, {
                  {"GLDesc", each Text.From(List.First([GLDesc]) ?? ""), type text},
                  // the profit centre as the join actually sees it, once leading zeros,
                  // spaces and punctuation are off it - so a mismatch between how the export
                  // and the sheet write the same code is visible rather than deduced
                  {"PCKey", each Text.From(List.First([PCKey]) ?? ""), type text},
                  {"OnSheetAsGL", each List.AnyTrue(List.Transform([Whitelisted], each _ = true)),
                   type logical},
                  // why it went nowhere, in words rather than by deduction
                  {"Reason", each
                       let A = Text.From(List.First(List.RemoveNulls([AmbigPlants])) ?? "") in
                       if A <> "" then "two plants on TB Master for this pair: " & A
                       else "no row on TB Master for this GL and profit centre", type text},
                  {"Rows", each Table.RowCount(_), Int64.Type},
                  {"AmountRsCr", each List.Sum(List.Transform([Amount], each _ ?? 0)) / 10000000,
                   type number}}),
    // biggest money first: that is the row worth typing in next
    Sorted  = Table.Sort(Grouped, {{"AmountRsCr", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"GLAccount", type text}, {"ProfitCentre", type text},
                  {"PCKey", type text}, {"GLDesc", type text}, {"Reason", type text}})
in
    Typed
