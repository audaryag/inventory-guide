let
    Src     = Table.SelectRows(factTB_Staged, each [PairMatched] = false),
    Named   = Table.TransformColumns(Src, {
                  {"ProfitCentre", each if Text.From(_ ?? "") = "" then "(blank)" else _,
                   type text}}),
    Grouped = Table.Group(Named, {"GLAccount", "ProfitCentre"}, {
                  {"GLDesc", each Text.From(List.First([GLDesc]) ?? ""), type text},
                  {"OnSheetAsGL", each List.AnyTrue(List.Transform([Whitelisted], each _ = true)),
                   type logical},
                  {"Rows", each Table.RowCount(_), Int64.Type},
                  {"AmountRsCr", each List.Sum(List.Transform([Amount], each _ ?? 0)) / 10000000,
                   type number}}),
    // biggest money first: that is the row worth typing in next
    Sorted  = Table.Sort(Grouped, {{"AmountRsCr", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"GLAccount", type text}, {"ProfitCentre", type text},
                  {"GLDesc", type text}})
in
    Typed
