let
    MB5B    = List.Distinct(List.RemoveNulls(factInventory[Material])),
    RM      = List.Distinct(List.RemoveNulls(dimMaterialAttr[Material])),
    FG      = List.Distinct(List.RemoveNulls(dimFGAttr[Material])),
    Sample  = (l as list) as text =>
                  Text.Combine(List.Transform(List.FirstN(List.Sort(l), 8), Text.From), " | "),
    Rows    = {
        {"Stock files (MB5B)", List.Count(MB5B), null, Sample(MB5B)},
        {"RM Nature sheet",    List.Count(RM),
         List.Count(List.Intersect({RM, MB5B})), Sample(RM)},
        {"FG Master sheet",    List.Count(FG),
         List.Count(List.Intersect({FG, MB5B})), Sample(FG)}
    },
    T       = Table.FromRows(Rows,
                  type table [Source = text, DistinctMaterials = Int64.Type,
                              MatchedToStockFiles = Int64.Type, FirstEight = text])
in
    T
