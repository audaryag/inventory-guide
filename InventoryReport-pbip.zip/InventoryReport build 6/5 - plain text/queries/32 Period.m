Period = {
    ("By Month",   NAMEOF('dimDate'[MonthName]), 0),
    ("By Quarter", NAMEOF('dimDate'[Quarter]),   1)
}
