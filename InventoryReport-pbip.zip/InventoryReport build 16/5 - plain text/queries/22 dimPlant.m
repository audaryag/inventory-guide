let
    Named    = #table(
        type table [ValuationArea = text, Plant = text, PlantSort = Int64.Type],
        {
            {"1900", "1900 Jaipur Module",  1},
            {"1902", "1902 Dholera Module", 2},
            {"1905", "1905 Dholera Cell",   3}
        }),
        // There are three plants and there is no fourth row. Every other code the files throw
        // up - 1903, 1904, 1908, blank - is not a plant, and factInventory and factTB_Staged
        // leave those rows out rather than inventing an Unallocated plant to hold them.
    // codes present in the stock files or the trial balance but not named above. Only other
    // queries are read here and no folder is opened, which is what keeps the firewall quiet.
    Seen     = List.Distinct(List.RemoveNulls(
                   List.Combine({factInventory[ValuationArea], factTB_Staged[ValuationArea]}))),
    // a named plant with nothing behind it is left out, so the Plant slicer lists what the
    // files actually contain and not a fixed list padded with rows that pick nothing
    Live     = Table.SelectRows(Named, each List.Contains(Seen, [ValuationArea])),
    Kept     = if Table.IsEmpty(Live) then Named else Live,
    Dedup    = Table.Distinct(Kept, {"ValuationArea"})
in
    Dedup
