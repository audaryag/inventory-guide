let
    Src     = factInventory,
    Latest  = List.Max(List.Transform(Table.Column(Src, "Month"), each _)),
    OneMon  = Table.SelectRows(Src, each [Month] = Latest),
    Grouped = Table.Group(OneMon,
                  {"ValuationArea", "Category", "Nature"}, {
                  {"Rows",      each Table.RowCount(_), Int64.Type},
                  {"Materials", each List.Count(List.Distinct([Material])), Int64.Type},
                  {"CloseQty",  each List.Sum(List.Transform([CloseQty], each _ ?? 0)),
                   type number},
                  {"MWValue",   each List.Sum(List.Transform([MW Qty], each _ ?? 0)),
                   type number},
                  {"RsCr",      each List.Sum(List.Transform([CloseVal], each _ ?? 0)) / 10000000,
                   type number}}),
    // the watts per piece the two columns imply, which is the number to compare against the
    // rate the working uses - 580 for a module, and whatever a cell is rated at
    Rate    = Table.AddColumn(Grouped, "WattsPerPiece",
                  each if [CloseQty] = null or [CloseQty] = 0 then null
                       else try [MWValue] * 1000000 / [CloseQty] otherwise null, type number),
    Stamped = Table.AddColumn(Rate, "Month", each Latest, type date),
    Sorted  = Table.Sort(Stamped, {{"ValuationArea", Order.Ascending},
                  {"Category", Order.Ascending}, {"RsCr", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"ValuationArea", type text}, {"Category", type text},
                  {"Nature", type text}, {"Month", type date}})
in
    Typed
