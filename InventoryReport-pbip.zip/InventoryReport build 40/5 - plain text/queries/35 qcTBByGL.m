let
    Grouped = Table.Group(factTB, {"GLAccount", "GLDesc", "Nature", "Category", "ValuationArea"}, {
              {"Rule", each Text.Combine(List.Distinct(List.Transform([Rule],
                                each Text.From(_ ?? ""))), " | "), type text},
                  {"AmountRsCr", each List.Sum([Amount]) / 10000000, type number},
                  {"Rows", each Table.RowCount(_), Int64.Type}}),
    Sorted  = Table.Sort(Grouped, {{"AmountRsCr", Order.Ascending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"GLAccount", type text}, {"GLDesc", type text},
                  {"Nature", type text}, {"Category", type text},
                  {"ValuationArea", type text}})
in
    Typed
