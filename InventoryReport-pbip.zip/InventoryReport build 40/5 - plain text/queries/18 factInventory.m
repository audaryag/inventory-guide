let
    Combined = Table.Combine({factRM, factFG, factConble}),
    Wanted   = {"SourceFile","ValuationArea","Material","MatKey","MaterialDesc",
                "FromDate","ToDate","OpenQty","OpenVal","ReceiptQty","ReceiptVal",
                "IssueQty","IssueVal","CloseQty","CloseVal","BaseUOM","SpecialStock",
                "Currency","Month","Category","Nature","GroupNature","BOMStdQty","Item",
                "AttrMissing","MW","Rate","RateParseFailed","Mid","Base","INR_WP"},
    Padded   = List.Accumulate(List.Difference(Wanted, Table.ColumnNames(Combined)),
                   Combined, (t, c) => Table.AddColumn(t, c, each null)),
    Kept     = Table.SelectColumns(Padded, Wanted),
    Typed    = Table.TransformColumnTypes(Kept, {
                   {"SourceFile", type text}, {"ValuationArea", type text},
                   {"Material", type text}, {"MatKey", type text},
                   {"MaterialDesc", type text}, {"FromDate", type date},
                   {"ToDate", type date}, {"OpenQty", type number},
                   {"OpenVal", type number}, {"ReceiptQty", type number},
                   {"ReceiptVal", type number}, {"IssueQty", type number},
                   {"IssueVal", type number}, {"CloseQty", type number},
                   {"CloseVal", type number}, {"BaseUOM", type text},
                   {"SpecialStock", type text}, {"Currency", type text},
                   {"Month", type date}, {"Category", type text},
                   {"Nature", type text}, {"GroupNature", type text},
                   {"BOMStdQty", type number}, {"Item", type text},
                   {"AttrMissing", type logical}, {"MW", type number},
                   {"Rate", type number}, {"RateParseFailed", type logical},
                   {"Mid", type text}, {"Base", type text}, {"INR_WP", type number}}),
    // last line of defence against a blank category: whatever slipped through above is
    // named, so no visual anywhere can show a nameless (Blank) row
    NoNulls  = Table.TransformColumns(Typed, {
                   {"Nature",      each if _ = null or _ = "" then "Unassigned" else _, type text},
                   {"GroupNature", each if _ = null or _ = "" then "Unassigned" else _, type text}}),
    // Every plant code the exports contain is reported, under the name Plant Master or
    // TB Master gives it and under its own code where they give none. Keeping only the codes
    // on Plant Master left whole plants out of the figures with nothing on the page to say
    // so; the only row dropped now is one with no valuation area at all, which belongs to no
    // plant by definition. qcPlantCodes on Checks still lists every code and what it holds.
    Plants   = varPlantCodes,
    OnePlant = Table.SelectRows(NoNulls,
                   each Text.Trim(Text.From([ValuationArea] ?? "")) <> ""),
    Trimmed  = Table.TransformColumns(OnePlant, {
                   {"ValuationArea", each Text.Trim(Text.From(_)), type text}}),
    // Duplicates. The same stock line can arrive twice - the same month exported twice into
    // the same folder, or a file copied under a second name - and two identical lines would
    // double that material's stock. A row is treated as the same line when its plant,
    // material, month, special stock, unit and every figure agree; the file it came from is
    // deliberately not part of that test, which is what catches the same month in two files.
    // Two genuinely different lines for one material in one month (different batch, different
    // special stock) differ in at least one figure and are both kept.
    DedupKey = {"ValuationArea","Material","Month","SpecialStock","BaseUOM",
                "OpenQty","OpenVal","ReceiptQty","ReceiptVal","IssueQty","IssueVal",
                "CloseQty","CloseVal","Category"},
    OneEach  = Table.Distinct(Trimmed, DedupKey),
    // the megawatt column is renamed because Power BI will not let a table hold a column
    // and a measure with the same name, and the report needs the measure to be called MW
    Renamed  = Table.RenameColumns(OneEach, {{"MW", "MW Qty"}}),
    // the flat plant-and-type key. dimPlantType joins on it, which is what lets a matrix show
    // one row per plant AND type without a two-level row hierarchy - and a hierarchy is the
    // one thing some versions of Desktop insist on opening collapsed, hiding the rows.
    Keyed    = Table.AddColumn(Renamed, "PlantType",
                   each Text.From([ValuationArea] ?? "") & "|" & Text.From([Category] ?? ""),
                   type text)
in
    Keyed
