let
    Src     = Table.SelectRows(factInventory, each [Category] = "FG"),
    Latest  = List.Max(List.Transform(Table.Column(Src, "Month"), each _)),
    OneMon  = Table.SelectRows(Src, each [Month] = Latest),
    Grouped = Table.Group(OneMon, {"ValuationArea", "Material", "MaterialDesc"}, {
                  {"Rows",     each Table.RowCount(_), Int64.Type},
                  {"Nature",   each Text.From(List.First([Nature]) ?? ""), type text},
                  {"Rate",     each List.Max(List.Transform([Rate], each _ ?? 0)), type number},
                  {"CloseQty", each List.Sum(List.Transform([CloseQty], each _ ?? 0)),
                   type number},
                  {"MWValue",  each List.Sum(List.Transform([MW Qty], each _ ?? 0)),
                   type number},
                  {"RsCr",     each List.Sum(List.Transform([CloseVal], each _ ?? 0)) / 10000000,
                   type number}}),
    // twelve rows a plant, biggest megawatts first: enough to account for a plant's figure,
    // few enough to photograph
    ByPlant = Table.Group(Grouped, {"ValuationArea"}, {
                  {"Top", each Table.FirstN(
                      Table.Sort(_, {{"MWValue", Order.Descending}}), 12), type table}}),
    Kept    = Table.Combine(Table.Column(ByPlant, "Top")),
    Stamped = Table.AddColumn(Kept, "Month", each Latest, type date),
    Sorted  = Table.Sort(Stamped, {{"ValuationArea", Order.Ascending},
                  {"MWValue", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"ValuationArea", type text}, {"Material", type text},
                  {"MaterialDesc", type text}, {"Nature", type text}, {"Month", type date}})
in
    Typed
