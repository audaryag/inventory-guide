let
    Src     = factTB_Staged,
    Latest  = List.Max(List.Transform(Table.Column(Src, "Month"), each _)),
    OneMon  = Table.SelectRows(Src, each [Month] = Latest),
    Named   = Table.TransformColumns(OneMon, {
                  {"ValuationArea", each if Text.From(_ ?? "") = "" then "(none)" else _,
                   type text},
                  {"Nature",        each if Text.From(_ ?? "") = "" then "(none)" else _,
                   type text},
                  {"Rule",          each if Text.From(_ ?? "") = "" then "(none)" else _,
                   type text}}),
    Grouped = Table.Group(Named, {"ValuationArea", "Nature", "Rule"}, {
                  {"Rows",       each Table.RowCount(_), Int64.Type},
                  {"GLAccounts", each List.Count(List.Distinct([GLAccount])), Int64.Type},
                  {"AmountRsCr", each List.Sum(List.Transform([Amount], each _ ?? 0)) / 10000000,
                   type number}}),
    Stamped = Table.AddColumn(Grouped, "Month", each Latest, type date),
    Sorted  = Table.Sort(Stamped, {{"ValuationArea", Order.Ascending},
                  {"AmountRsCr", Order.Descending}}),
    Typed   = Table.TransformColumnTypes(Sorted, {
                  {"Month", type date}, {"ValuationArea", type text},
                  {"Nature", type text}, {"Rule", type text}})
in
    Typed
