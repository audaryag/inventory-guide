# Sets pRoot inside an extracted project folder, so nothing is typed in Power BI.
#   Right-click this file -> Run with PowerShell, or:
#   powershell -ExecutionPolicy Bypass -File .\set-proot.ps1 -Root "C:\Users\me\Desktop\Inventory Report"
param([Parameter(Mandatory=$true)][string]$Root)

if (-not (Test-Path -LiteralPath $Root)) { throw "That folder does not exist: $Root" }
foreach ($sub in 'RM Raw','FG Raw','Consble Raw','TB') {
  if (-not (Test-Path -LiteralPath (Join-Path $Root $sub))) {
    Write-Warning "No '$sub' sub-folder inside $Root - refresh will fail until it exists."
  }
}
$Root = $Root.TrimEnd('\')
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$hits = Get-ChildItem -LiteralPath $here -Recurse -Filter model.bim
if (-not $hits) { throw "No model.bim found under $here - extract the zip first." }

foreach ($f in $hits) {
  $json = Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json
  $p = $json.model.expressions | Where-Object { $_.name -eq 'pRoot' }
  if (-not $p) { Write-Warning "no pRoot in $($f.FullName)"; continue }
  $esc = $Root -replace '\\', '\\'
  $p.expression = '"' + $esc + '" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
  $json | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $f.FullName -Encoding UTF8
  Write-Host "pRoot set to $Root in $($f.Directory.Name)"
}
Write-Host "Done. Open the .pbip and press Refresh."
