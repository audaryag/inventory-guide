// Tabular Editor 2 -> C# Script tab -> paste -> F5, then Ctrl+S.
// Creates or overwrites every report measure on factInventory.
var t = Model.Tables["factInventory"];
int made = 0, updated = 0;
if (t.Measures.Contains("Value ₹ Cr")) { t.Measures["Value ₹ Cr"].Expression = @"DIVIDE(SUM(factInventory[CloseVal]), 10000000)"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr", @"DIVIDE(SUM(factInventory[CloseVal]), 10000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("As On")) { t.Measures["As On"].Expression = @"""as on "" & FORMAT(EOMONTH(MAX(dimDate[Month]), 0), ""dd MMM yyyy"")"; updated++; }
else { var m = t.AddMeasure("As On", @"""as on "" & FORMAT(EOMONTH(MAX(dimDate[Month]), 0), ""dd MMM yyyy"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr Title")) { t.Measures["Value ₹ Cr Title"].Expression = @"""Value ₹ Cr "" & [As On]"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr Title", @"""Value ₹ Cr "" & [As On]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Opening Value ₹ Cr")) { t.Measures["Opening Value ₹ Cr"].Expression = @"DIVIDE(SUM(factInventory[OpenVal]), 10000000)"; updated++; }
else { var m = t.AddMeasure("Opening Value ₹ Cr", @"DIVIDE(SUM(factInventory[OpenVal]), 10000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Receipts ₹ Cr")) { t.Measures["Receipts ₹ Cr"].Expression = @"DIVIDE(SUM(factInventory[ReceiptVal]), 10000000)"; updated++; }
else { var m = t.AddMeasure("Receipts ₹ Cr", @"DIVIDE(SUM(factInventory[ReceiptVal]), 10000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Issues ₹ Cr")) { t.Measures["Issues ₹ Cr"].Expression = @"DIVIDE(SUM(factInventory[IssueVal]), 10000000)"; updated++; }
else { var m = t.AddMeasure("Issues ₹ Cr", @"DIVIDE(SUM(factInventory[IssueVal]), 10000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Closing Qty")) { t.Measures["Closing Qty"].Expression = @"SUM(factInventory[CloseQty])"; updated++; }
else { var m = t.AddMeasure("Closing Qty", @"SUM(factInventory[CloseQty])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("RM ₹ Cr")) { t.Measures["RM ₹ Cr"].Expression = @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""RM"")"; updated++; }
else { var m = t.AddMeasure("RM ₹ Cr", @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""RM"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("FG ₹ Cr")) { t.Measures["FG ₹ Cr"].Expression = @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""FG"")"; updated++; }
else { var m = t.AddMeasure("FG ₹ Cr", @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""FG"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Consumables ₹ Cr")) { t.Measures["Consumables ₹ Cr"].Expression = @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""Consumables"")"; updated++; }
else { var m = t.AddMeasure("Consumables ₹ Cr", @"CALCULATE([Value ₹ Cr], factInventory[Category] = ""Consumables"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Share of Total %")) { t.Measures["Share of Total %"].Expression = @"DIVIDE([Value ₹ Cr], CALCULATE([Value ₹ Cr], ALL(factInventory[Category])))"; updated++; }
else { var m = t.AddMeasure("Share of Total %", @"DIVIDE([Value ₹ Cr], CALCULATE([Value ₹ Cr], ALL(factInventory[Category])))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("MW")) { t.Measures["MW"].Expression = @"SUM(factInventory[MW Qty])"; updated++; }
else { var m = t.AddMeasure("MW", @"SUM(factInventory[MW Qty])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("FG MW")) { t.Measures["FG MW"].Expression = @"CALCULATE([MW], factInventory[Category] = ""FG"")"; updated++; }
else { var m = t.AddMeasure("FG MW", @"CALCULATE([MW], factInventory[Category] = ""FG"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Capacity MW")) { t.Measures["Capacity MW"].Expression = @"SUM(dimCapacity[CapacityMW])"; updated++; }
else { var m = t.AddMeasure("Capacity MW", @"SUM(dimCapacity[CapacityMW])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Capacity MW (plant)")) { t.Measures["Capacity MW (plant)"].Expression = @"CALCULATE(SUM(dimCapacity[CapacityMW]), REMOVEFILTERS(dimNature))"; updated++; }
else { var m = t.AddMeasure("Capacity MW (plant)", @"CALCULATE(SUM(dimCapacity[CapacityMW]), REMOVEFILTERS(dimNature))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Days of Inventory")) { t.Measures["Days of Inventory"].Expression = @"VAR Cap = IF(ISBLANK([Capacity MW]), [Capacity MW (plant)], [Capacity MW])
RETURN DIVIDE([MW], Cap)"; updated++; }
else { var m = t.AddMeasure("Days of Inventory", @"VAR Cap = IF(ISBLANK([Capacity MW]), [Capacity MW (plant)], [Capacity MW])
RETURN DIVIDE([MW], Cap)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("FG Days")) { t.Measures["FG Days"].Expression = @"DIVIDE([FG MW], [Capacity MW])"; updated++; }
else { var m = t.AddMeasure("FG Days", @"DIVIDE([FG MW], [Capacity MW])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("INR per Wp")) { t.Measures["INR per Wp"].Expression = @"DIVIDE(SUM(factInventory[CloseVal]), SUM(factInventory[MW Qty]) * 1000000)"; updated++; }
else { var m = t.AddMeasure("INR per Wp", @"DIVIDE(SUM(factInventory[CloseVal]), SUM(factInventory[MW Qty]) * 1000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr LM")) { t.Measures["Value ₹ Cr LM"].Expression = @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([Value ₹ Cr], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr LM", @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([Value ₹ Cr], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr vs LM")) { t.Measures["Value ₹ Cr vs LM"].Expression = @"[Value ₹ Cr] - [Value ₹ Cr LM]"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr vs LM", @"[Value ₹ Cr] - [Value ₹ Cr LM]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr % vs LM")) { t.Measures["Value ₹ Cr % vs LM"].Expression = @"DIVIDE([Value ₹ Cr vs LM], [Value ₹ Cr LM])"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr % vs LM", @"DIVIDE([Value ₹ Cr vs LM], [Value ₹ Cr LM])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr LY")) { t.Measures["Value ₹ Cr LY"].Expression = @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 12
RETURN CALCULATE([Value ₹ Cr], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr LY", @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 12
RETURN CALCULATE([Value ₹ Cr], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Value ₹ Cr % vs LY")) { t.Measures["Value ₹ Cr % vs LY"].Expression = @"DIVIDE([Value ₹ Cr] - [Value ₹ Cr LY], [Value ₹ Cr LY])"; updated++; }
else { var m = t.AddMeasure("Value ₹ Cr % vs LY", @"DIVIDE([Value ₹ Cr] - [Value ₹ Cr LY], [Value ₹ Cr LY])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("MW LM")) { t.Measures["MW LM"].Expression = @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([MW], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"; updated++; }
else { var m = t.AddMeasure("MW LM", @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([MW], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("MW vs LM")) { t.Measures["MW vs LM"].Expression = @"[MW] - [MW LM]"; updated++; }
else { var m = t.AddMeasure("MW vs LM", @"[MW] - [MW LM]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Days LM")) { t.Measures["Days LM"].Expression = @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([Days of Inventory], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"; updated++; }
else { var m = t.AddMeasure("Days LM", @"VAR PrevIdx = MAX(dimDate[MonthIndex]) - 1
RETURN CALCULATE([Days of Inventory], ALL(dimDate), dimDate[MonthIndex] = PrevIdx)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Days vs LM")) { t.Measures["Days vs LM"].Expression = @"[Days of Inventory] - [Days LM]"; updated++; }
else { var m = t.AddMeasure("Days vs LM", @"[Days of Inventory] - [Days LM]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Avg Value ₹ Cr")) { t.Measures["Avg Value ₹ Cr"].Expression = @"AVERAGEX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])"; updated++; }
else { var m = t.AddMeasure("Avg Value ₹ Cr", @"AVERAGEX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Peak Value ₹ Cr")) { t.Measures["Peak Value ₹ Cr"].Expression = @"MAXX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])"; updated++; }
else { var m = t.AddMeasure("Peak Value ₹ Cr", @"MAXX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Latest Month Value ₹ Cr")) { t.Measures["Latest Month Value ₹ Cr"].Expression = @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([Value ₹ Cr], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"; updated++; }
else { var m = t.AddMeasure("Latest Month Value ₹ Cr", @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([Value ₹ Cr], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Latest Month MW")) { t.Measures["Latest Month MW"].Expression = @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([MW], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"; updated++; }
else { var m = t.AddMeasure("Latest Month MW", @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([MW], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Latest Month FG ₹ Cr")) { t.Measures["Latest Month FG ₹ Cr"].Expression = @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([FG ₹ Cr], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"; updated++; }
else { var m = t.AddMeasure("Latest Month FG ₹ Cr", @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALLSELECTED(dimDate))
RETURN CALCULATE([FG ₹ Cr], FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("TB ₹ Cr")) { t.Measures["TB ₹ Cr"].Expression = @"ROUND(DIVIDE(SUM(factTB[Amount]), 10000000), 2)"; updated++; }
else { var m = t.AddMeasure("TB ₹ Cr", @"ROUND(DIVIDE(SUM(factTB[Amount]), 10000000), 2)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Difference ₹ Cr")) { t.Measures["Difference ₹ Cr"].Expression = @"[TB ₹ Cr] - [Value ₹ Cr]"; updated++; }
else { var m = t.AddMeasure("Difference ₹ Cr", @"[TB ₹ Cr] - [Value ₹ Cr]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Difference %")) { t.Measures["Difference %"].Expression = @"DIVIDE([Difference ₹ Cr], [TB ₹ Cr])"; updated++; }
else { var m = t.AddMeasure("Difference %", @"DIVIDE([Difference ₹ Cr], [TB ₹ Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Stock Recon ₹ Cr")) { t.Measures["Stock Recon ₹ Cr"].Expression = @"[Opening Value ₹ Cr] + [Receipts ₹ Cr] - [Issues ₹ Cr] - [Value ₹ Cr]"; updated++; }
else { var m = t.AddMeasure("Stock Recon ₹ Cr", @"[Opening Value ₹ Cr] + [Receipts ₹ Cr] - [Issues ₹ Cr] - [Value ₹ Cr]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Rows Missing Attr")) { t.Measures["Rows Missing Attr"].Expression = @"CALCULATE(COUNTROWS(factInventory), factInventory[AttrMissing] = TRUE())"; updated++; }
else { var m = t.AddMeasure("Rows Missing Attr", @"CALCULATE(COUNTROWS(factInventory), factInventory[AttrMissing] = TRUE())"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Unmapped TB ₹ Cr")) { t.Measures["Unmapped TB ₹ Cr"].Expression = @"DIVIDE(SUM(factTB_Unmapped[Amount]), 10000000)"; updated++; }
else { var m = t.AddMeasure("Unmapped TB ₹ Cr", @"DIVIDE(SUM(factTB_Unmapped[Amount]), 10000000)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Days")) { t.Measures["Days"].Expression = @"[Days of Inventory]"; updated++; }
else { var m = t.AddMeasure("Days", @"[Days of Inventory]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Summary Value ₹ Cr")) { t.Measures["Summary Value ₹ Cr"].Expression = @"SWITCH(SELECTEDVALUE(dimMetric[Metric]),
    ""Inventory (TB)"",   [TB ₹ Cr],
    ""Inventory (MB5B)"", [Value ₹ Cr],
    ""Difference"",       [Difference ₹ Cr],
    [Value ₹ Cr])"; updated++; }
else { var m = t.AddMeasure("Summary Value ₹ Cr", @"SWITCH(SELECTEDVALUE(dimMetric[Metric]),
    ""Inventory (TB)"",   [TB ₹ Cr],
    ""Inventory (MB5B)"", [Value ₹ Cr],
    ""Difference"",       [Difference ₹ Cr],
    [Value ₹ Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Unit Value")) { t.Measures["Unit Value"].Expression = @"SWITCH(SELECTEDVALUE(dimMeasure[Measure]),
    ""MW"",      [MW],
    ""In ₹ Cr"", [Value ₹ Cr],
    ""In Days"", [Days],
    [Value ₹ Cr])"; updated++; }
else { var m = t.AddMeasure("Unit Value", @"SWITCH(SELECTEDVALUE(dimMeasure[Measure]),
    ""MW"",      [MW],
    ""In ₹ Cr"", [Value ₹ Cr],
    ""In Days"", [Days],
    [Value ₹ Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Last 4 Months")) { t.Measures["Last 4 Months"].Expression = @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALL(dimDate))
RETURN IF(MAX(dimDate[MonthIndex]) > LastIdx - 4, 1, 0)"; updated++; }
else { var m = t.AddMeasure("Last 4 Months", @"VAR LastIdx = CALCULATE(MAX(dimDate[MonthIndex]), ALL(dimDate))
RETURN IF(MAX(dimDate[MonthIndex]) > LastIdx - 4, 1, 0)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Latest Month Index")) { t.Measures["Latest Month Index"].Expression = @"CALCULATE(MAX(dimDate[MonthIndex]), REMOVEFILTERS())"; updated++; }
else { var m = t.AddMeasure("Latest Month Index", @"CALCULATE(MAX(dimDate[MonthIndex]), REMOVEFILTERS())"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("As On Text")) { t.Measures["As On Text"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN ""As on "" & CALCULATE(MAX(dimDate[MonthName]), REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"; updated++; }
else { var m = t.AddMeasure("As On Text", @"VAR LastIdx = [Latest Month Index]
RETURN ""As on "" & CALCULATE(MAX(dimDate[MonthName]), REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Rs Cr")) { t.Measures["Ticker Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"; updated++; }
else { var m = t.AddMeasure("Ticker Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker RM Rs Cr")) { t.Measures["Ticker RM Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""RM""))"; updated++; }
else { var m = t.AddMeasure("Ticker RM Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""RM""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker FG Rs Cr")) { t.Measures["Ticker FG Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""FG""))"; updated++; }
else { var m = t.AddMeasure("Ticker FG Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""FG""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Consumables Rs Cr")) { t.Measures["Ticker Consumables Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""Consumables""))"; updated++; }
else { var m = t.AddMeasure("Ticker Consumables Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimCategory), dimCategory[Category] = ""Consumables""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker 1900 Rs Cr")) { t.Measures["Ticker 1900 Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1900""))"; updated++; }
else { var m = t.AddMeasure("Ticker 1900 Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1900""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker 1902 Rs Cr")) { t.Measures["Ticker 1902 Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1902""))"; updated++; }
else { var m = t.AddMeasure("Ticker 1902 Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1902""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker 1905 Rs Cr")) { t.Measures["Ticker 1905 Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1905""))"; updated++; }
else { var m = t.AddMeasure("Ticker 1905 Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx),
    FILTER(ALL(dimPlant), dimPlant[ValuationArea] = ""1905""))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Prev Rs Cr")) { t.Measures["Ticker Prev Rs Cr"].Expression = @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx - 1))"; updated++; }
else { var m = t.AddMeasure("Ticker Prev Rs Cr", @"VAR LastIdx = [Latest Month Index]
RETURN CALCULATE([Value ₹ Cr], REMOVEFILTERS(),
    FILTER(ALL(dimDate), dimDate[MonthIndex] = LastIdx - 1))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Change Rs Cr")) { t.Measures["Ticker Change Rs Cr"].Expression = @"[Ticker Rs Cr] - [Ticker Prev Rs Cr]"; updated++; }
else { var m = t.AddMeasure("Ticker Change Rs Cr", @"[Ticker Rs Cr] - [Ticker Prev Rs Cr]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Change %")) { t.Measures["Ticker Change %"].Expression = @"DIVIDE([Ticker Change Rs Cr], [Ticker Prev Rs Cr])"; updated++; }
else { var m = t.AddMeasure("Ticker Change %", @"DIVIDE([Ticker Change Rs Cr], [Ticker Prev Rs Cr])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Ticker Change Text")) { t.Measures["Ticker Change Text"].Expression = @"IF(
    ISBLANK([Ticker Prev Rs Cr]),
    ""No earlier month to compare"",
    FORMAT([Ticker Change Rs Cr], ""+#,##0.0;-#,##0.0"") & "" Rs Cr.   (""
        & FORMAT([Ticker Change %], ""+0.0%;-0.0%"") & "")""
)"; updated++; }
else { var m = t.AddMeasure("Ticker Change Text", @"IF(
    ISBLANK([Ticker Prev Rs Cr]),
    ""No earlier month to compare"",
    FORMAT([Ticker Change Rs Cr], ""+#,##0.0;-#,##0.0"") & "" Rs Cr.   (""
        & FORMAT([Ticker Change %], ""+0.0%;-0.0%"") & "")""
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Inventory Rs Cr")) { t.Measures["Inventory Rs Cr"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Value ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])
)"; updated++; }
else { var m = t.AddMeasure("Inventory Rs Cr", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Value ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Value ₹ Cr])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("In Window")) { t.Measures["In Window"].Expression = @"VAR Picked = ISFILTERED(dimDate[MonthName])
VAR Me = MAX(dimDate[MonthIndex])
VAR Live =
    CALCULATETABLE(VALUES(dimDate[MonthIndex]), REMOVEFILTERS(), factInventory)
VAR LastIdx = MAXX(Live, dimDate[MonthIndex])
VAR MarchIdx =
    MAXX(
        FILTER(
            ALL(dimDate),
            dimDate[FYMonthNo] = 12
                && dimDate[MonthIndex] <= LastIdx
                && CALCULATE(COUNTROWS(factInventory)) > 0),
        dimDate[MonthIndex])
VAR Alive = COUNTROWS(FILTER(Live, dimDate[MonthIndex] = Me))
VAR Place = COUNTROWS(FILTER(Live, dimDate[MonthIndex] > Me)) + 1
RETURN
IF(
    Picked,
    1,
    IF(
        Alive > 0
            && Me >= MarchIdx
            && (Place <= 4 || Me = MarchIdx),
        1,
        0)
)"; updated++; }
else { var m = t.AddMeasure("In Window", @"VAR Picked = ISFILTERED(dimDate[MonthName])
VAR Me = MAX(dimDate[MonthIndex])
VAR Live =
    CALCULATETABLE(VALUES(dimDate[MonthIndex]), REMOVEFILTERS(), factInventory)
VAR LastIdx = MAXX(Live, dimDate[MonthIndex])
VAR MarchIdx =
    MAXX(
        FILTER(
            ALL(dimDate),
            dimDate[FYMonthNo] = 12
                && dimDate[MonthIndex] <= LastIdx
                && CALCULATE(COUNTROWS(factInventory)) > 0),
        dimDate[MonthIndex])
VAR Alive = COUNTROWS(FILTER(Live, dimDate[MonthIndex] = Me))
VAR Place = COUNTROWS(FILTER(Live, dimDate[MonthIndex] > Me)) + 1
RETURN
IF(
    Picked,
    1,
    IF(
        Alive > 0
            && Me >= MarchIdx
            && (Place <= 4 || Me = MarchIdx),
        1,
        0)
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("In Summary Window")) { t.Measures["In Summary Window"].Expression = @"VAR Picked = ISFILTERED(dimDate[MonthName])
VAR Me = MAX(dimDate[MonthIndex])
VAR Live =
    CALCULATETABLE(VALUES(dimDate[MonthIndex]), REMOVEFILTERS(), factInventory)
VAR LastIdx = MAXX(Live, dimDate[MonthIndex])
VAR MarchIdx =
    MAXX(
        FILTER(
            ALL(dimDate),
            dimDate[FYMonthNo] = 12
                && dimDate[MonthIndex] <= LastIdx
                && CALCULATE(COUNTROWS(factInventory)) > 0),
        dimDate[MonthIndex])
VAR Alive = COUNTROWS(FILTER(Live, dimDate[MonthIndex] = Me))
VAR Place = COUNTROWS(FILTER(Live, dimDate[MonthIndex] > Me)) + 1
RETURN
IF(
    Picked,
    IF(Place <= 12, 1, 0),
    IF(Alive > 0 && (Me = MarchIdx || Place <= 3), 1, 0)
)"; updated++; }
else { var m = t.AddMeasure("In Summary Window", @"VAR Picked = ISFILTERED(dimDate[MonthName])
VAR Me = MAX(dimDate[MonthIndex])
VAR Live =
    CALCULATETABLE(VALUES(dimDate[MonthIndex]), REMOVEFILTERS(), factInventory)
VAR LastIdx = MAXX(Live, dimDate[MonthIndex])
VAR MarchIdx =
    MAXX(
        FILTER(
            ALL(dimDate),
            dimDate[FYMonthNo] = 12
                && dimDate[MonthIndex] <= LastIdx
                && CALCULATE(COUNTROWS(factInventory)) > 0),
        dimDate[MonthIndex])
VAR Alive = COUNTROWS(FILTER(Live, dimDate[MonthIndex] = Me))
VAR Place = COUNTROWS(FILTER(Live, dimDate[MonthIndex] > Me)) + 1
RETURN
IF(
    Picked,
    IF(Place <= 12, 1, 0),
    IF(Alive > 0 && (Me = MarchIdx || Place <= 3), 1, 0)
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("MW % vs LM")) { t.Measures["MW % vs LM"].Expression = @"DIVIDE([MW] - [MW LM], [MW LM])"; updated++; }
else { var m = t.AddMeasure("MW % vs LM", @"DIVIDE([MW] - [MW LM], [MW LM])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("RM MW")) { t.Measures["RM MW"].Expression = @"CALCULATE([MW], factInventory[Category] = ""RM"")"; updated++; }
else { var m = t.AddMeasure("RM MW", @"CALCULATE([MW], factInventory[Category] = ""RM"")"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("RM Days")) { t.Measures["RM Days"].Expression = @"DIVIDE([RM MW], [Capacity MW (plant)])"; updated++; }
else { var m = t.AddMeasure("RM Days", @"DIVIDE([RM MW], [Capacity MW (plant)])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Total Days (RM + FG)")) { t.Measures["Total Days (RM + FG)"].Expression = @"DIVIDE([RM MW] + [FG MW], [Capacity MW (plant)])"; updated++; }
else { var m = t.AddMeasure("Total Days (RM + FG)", @"DIVIDE([RM MW] + [FG MW], [Capacity MW (plant)])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("RM Days All Plants")) { t.Measures["RM Days All Plants"].Expression = @"VAR M = CALCULATE([RM MW], REMOVEFILTERS(dimPlant))
VAR Cap = CALCULATE([Capacity MW (plant)], REMOVEFILTERS(dimPlant))
RETURN DIVIDE(M, Cap)"; updated++; }
else { var m = t.AddMeasure("RM Days All Plants", @"VAR M = CALCULATE([RM MW], REMOVEFILTERS(dimPlant))
VAR Cap = CALCULATE([Capacity MW (plant)], REMOVEFILTERS(dimPlant))
RETURN DIVIDE(M, Cap)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("RM Days All Plants by Period")) { t.Measures["RM Days All Plants by Period"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [RM Days All Plants],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [RM Days All Plants])
)"; updated++; }
else { var m = t.AddMeasure("RM Days All Plants by Period", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [RM Days All Plants],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [RM Days All Plants])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Inventory MW")) { t.Measures["Inventory MW"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [MW],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [MW])
)"; updated++; }
else { var m = t.AddMeasure("Inventory MW", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [MW],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [MW])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("In Last 12")) { t.Measures["In Last 12"].Expression = @"VAR LastM = [Latest Month Index]
VAR ThisM = MAX(dimDate[MonthIndex])
RETURN IF(ThisM > LastM - 12 && ThisM <= LastM, 1, 0)"; updated++; }
else { var m = t.AddMeasure("In Last 12", @"VAR LastM = [Latest Month Index]
VAR ThisM = MAX(dimDate[MonthIndex])
RETURN IF(ThisM > LastM - 12 && ThisM <= LastM, 1, 0)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Summary Value Rs Cr")) { t.Measures["Summary Value Rs Cr"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Summary Value ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Summary Value ₹ Cr])
)"; updated++; }
else { var m = t.AddMeasure("Summary Value Rs Cr", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Summary Value ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Summary Value ₹ Cr])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("TB Inventory Rs Cr")) { t.Measures["TB Inventory Rs Cr"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [TB ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [TB ₹ Cr])
)"; updated++; }
else { var m = t.AddMeasure("TB Inventory Rs Cr", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [TB ₹ Cr],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [TB ₹ Cr])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Difference Inventory Rs Cr")) { t.Measures["Difference Inventory Rs Cr"].Expression = @"[TB Inventory Rs Cr] - [Inventory Rs Cr]"; updated++; }
else { var m = t.AddMeasure("Difference Inventory Rs Cr", @"[TB Inventory Rs Cr] - [Inventory Rs Cr]"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Difference Inventory %")) { t.Measures["Difference Inventory %"].Expression = @"VAR Books = [TB Inventory Rs Cr]
RETURN IF(ABS(Books) < 0.05, BLANK(), DIVIDE([Difference Inventory Rs Cr], Books))"; updated++; }
else { var m = t.AddMeasure("Difference Inventory %", @"VAR Books = [TB Inventory Rs Cr]
RETURN IF(ABS(Books) < 0.05, BLANK(), DIVIDE([Difference Inventory Rs Cr], Books))"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Unit Value by Period")) { t.Measures["Unit Value by Period"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Unit Value],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Unit Value])
)"; updated++; }
else { var m = t.AddMeasure("Unit Value by Period", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Unit Value],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Unit Value])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("In Latest Month")) { t.Measures["In Latest Month"].Expression = @"IF(MAX(dimDate[MonthIndex]) = [Latest Month Index], 1, 0)"; updated++; }
else { var m = t.AddMeasure("In Latest Month", @"IF(MAX(dimDate[MonthIndex]) = [Latest Month Index], 1, 0)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Days by Period")) { t.Measures["Days by Period"].Expression = @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Days],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Days])
)"; updated++; }
else { var m = t.AddMeasure("Days by Period", @"IF(
    ISINSCOPE(dimDate[MonthName]),
    [Days],
    AVERAGEX(VALUES(dimDate[MonthIndex]), [Days])
)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Check MB5B Rows")) { t.Measures["Check MB5B Rows"].Expression = @"COUNTROWS(factInventory)"; updated++; }
else { var m = t.AddMeasure("Check MB5B Rows", @"COUNTROWS(factInventory)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Check TB Rows")) { t.Measures["Check TB Rows"].Expression = @"COUNTROWS(factTB)"; updated++; }
else { var m = t.AddMeasure("Check TB Rows", @"COUNTROWS(factTB)"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Check Months of Data")) { t.Measures["Check Months of Data"].Expression = @"DISTINCTCOUNT(factInventory[Month])"; updated++; }
else { var m = t.AddMeasure("Check Months of Data", @"DISTINCTCOUNT(factInventory[Month])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Check Plant Codes")) { t.Measures["Check Plant Codes"].Expression = @"DISTINCTCOUNT(factInventory[ValuationArea])"; updated++; }
else { var m = t.AddMeasure("Check Plant Codes", @"DISTINCTCOUNT(factInventory[ValuationArea])"); m.DisplayFolder = "Report measures"; made++; }
if (t.Measures.Contains("Check Unassigned %")) { t.Measures["Check Unassigned %"].Expression = @"VAR Unnamed =
    CALCULATE(
        SUM(factInventory[CloseVal]),
        factInventory[Nature] IN {""Unassigned"", ""(blank)""}
    )
RETURN
DIVIDE(Unnamed, SUM(factInventory[CloseVal]))"; updated++; }
else { var m = t.AddMeasure("Check Unassigned %", @"VAR Unnamed =
    CALCULATE(
        SUM(factInventory[CloseVal]),
        factInventory[Nature] IN {""Unassigned"", ""(blank)""}
    )
RETURN
DIVIDE(Unnamed, SUM(factInventory[CloseVal]))"); m.DisplayFolder = "Report measures"; made++; }
Info(made + " measures created, " + updated + " updated.");
