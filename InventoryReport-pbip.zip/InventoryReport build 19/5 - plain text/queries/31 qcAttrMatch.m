let
    MB5B    = List.Distinct(List.RemoveNulls(factInventory[Material])),
    RM      = List.Distinct(List.RemoveNulls(dimMaterialAttr[Material])),
    FG      = List.Distinct(List.RemoveNulls(dimFGAttr[Material])),
    Sample  = (l as list) as text =>
                  Text.Combine(List.Transform(List.FirstN(List.Sort(l), 8), Text.From), " | "),
    // the same question again on the description, because a master sheet keyed by description
    // rather than by material number would show Matched near zero above and healthy here
    MB5BD   = List.Distinct(List.RemoveNulls(List.Transform(factInventory[MaterialDesc],
                  each Text.Upper(Text.Trim(Text.From(_ ?? "")))))),
    RMD     = List.Distinct(List.RemoveNulls(List.Transform(dimMaterialAttr[DescKey],
                  each Text.Upper(Text.Trim(Text.From(_ ?? "")))))),
    Rows    = {
        {"Stock files (MB5B)", List.Count(MB5B), null, Sample(MB5B)},
        {"RM Nature sheet",    List.Count(RM),
         List.Count(List.Intersect({RM, MB5B})), Sample(RM)},
        {"FG Master sheet",    List.Count(FG),
         List.Count(List.Intersect({FG, MB5B})), Sample(FG)},
        {"Stock files - descriptions", List.Count(MB5BD), null, Sample(MB5BD)},
        {"RM Nature - descriptions",   List.Count(RMD),
         List.Count(List.Intersect({RMD, MB5BD})), Sample(RMD)}
    },
    T       = Table.FromRows(Rows,
                  type table [Source = text, DistinctMaterials = Int64.Type,
                              MatchedToStockFiles = Int64.Type, FirstEight = text])
in
    T
