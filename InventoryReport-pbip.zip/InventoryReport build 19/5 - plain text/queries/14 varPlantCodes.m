let
    FromMaster = try List.Distinct(List.RemoveNulls(dimPlantMaster[ValuationArea]))
                 otherwise {},
    Out        = if List.Count(FromMaster) = 0 then {"1900", "1902", "1905"} else FromMaster
in
    Out
