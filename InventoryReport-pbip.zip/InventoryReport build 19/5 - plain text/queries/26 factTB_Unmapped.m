let
    Out   = Table.SelectRows(factTB_Staged, each [Whitelisted] = false),
    Group = Table.Group(Out, {"GLAccount","GLDesc"},
                {{"Amount", each List.Sum([Amount]), type number},
                 {"Rows",   each Table.RowCount(_), Int64.Type}})
in
    Group
