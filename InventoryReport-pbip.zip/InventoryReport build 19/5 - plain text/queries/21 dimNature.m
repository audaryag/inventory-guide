let
    FromRM  = List.RemoveNulls(dimMaterialAttr[Nature]),
    FromFG  = List.RemoveNulls(dimFGAttr[Nature]),
    FromCap = List.RemoveNulls(varMWCapacity[Tech]),
    // 'Consumables' and 'Unassigned' are written by the fact queries rather than read from a
    // master sheet, so they have to be listed here as well. A nature that a fact row carries
    // and this table does not is what draws a slice labelled (Blank).
    All     = List.Distinct(List.Combine({FromRM, FromFG, FromCap,
                  {"Consumables", "Unassigned"}})),
    T       = Table.FromList(All, Splitter.SplitByNothing(), {"Nature"}),
    Typed   = Table.TransformColumnTypes(T, {{"Nature", type text}})
in
    Typed
