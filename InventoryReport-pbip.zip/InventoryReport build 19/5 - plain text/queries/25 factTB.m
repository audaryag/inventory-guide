let
    Kept    = Table.SelectRows(factTB_Staged, each [Whitelisted] = true),
    // RM / FG / Consumables from whatever the Nature (or GL description) says
    Bucket  = (n as any, d as any) as text =>
                  let T = Text.Upper(Text.From(n ?? "") & " " & Text.From(d ?? "")) in
                  if Text.Contains(T, "FINISH") or Text.Contains(T, "FG")
                      then "FG"
                  else if Text.Contains(T, "CONSUM") or Text.Contains(T, "STORE")
                      or Text.Contains(T, "SPARE") or Text.Contains(T, "PACK")
                      then "Consumables"
                  else if Text.Contains(T, "RAW") or Text.Contains(T, "RM")
                      or Text.Contains(T, "WIP") or Text.Contains(T, "SEMI")
                      then "RM"
                  else "RM",
    Cat     = Table.AddColumn(Kept, "Category",
                  each Bucket([Nature], [GLDesc]), type text),
    // exact column list and types, so the table is the same shape every refresh
    Wanted  = {"SourceFile","Month","GLAccount","GLDesc","ProfitCentre","ProfitCentreDesc",
               "Amount","PlantCode","ValuationArea","Nature","TBPlant","TBSort","Category"},
    Padded  = List.Accumulate(List.Difference(Wanted, Table.ColumnNames(Cat)), Cat,
                  (t, c) => Table.AddColumn(t, c, each null)),
    Slim    = Table.SelectColumns(Padded, Wanted),
    Typed   = Table.TransformColumnTypes(Slim, {
                  {"SourceFile", type text}, {"Month", type date},
                  {"GLAccount", type text}, {"GLDesc", type text},
                  {"ProfitCentre", type text}, {"ProfitCentreDesc", type text},
                  {"Amount", type number}, {"PlantCode", type text},
                  {"ValuationArea", type text}, {"Nature", type text},
                  {"TBPlant", type text}, {"TBSort", Int64.Type},
                  {"Category", type text}})
in
    Typed
