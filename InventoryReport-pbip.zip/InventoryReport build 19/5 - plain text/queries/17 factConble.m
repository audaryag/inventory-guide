let
    Src      = stgConble,
    Nature   = Table.AddColumn(Src, "Nature", each "Consumables", type text),
    Group    = Table.AddColumn(Nature, "GroupNature", each "Consumables", type text),
    Missing  = Table.AddColumn(Group, "AttrMissing", each false, type logical)
in
    Missing
