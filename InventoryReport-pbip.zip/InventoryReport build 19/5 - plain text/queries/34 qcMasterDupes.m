let
    NormMat = (v as any) as text =>
                  let Bare = Text.Select(Text.Upper(Text.From(v ?? "")), {"A".."Z", "0".."9"}),
                      Cut  = Text.TrimStart(Bare, "0")
                  in  if Cut = "" and Bare <> "" then "0" else Cut,
    Read    = (sheet as list, label as text) as table =>
        let
            Raw    = fnVarSheetSafe(sheet, {
                         {{"Valuation Area","Val Area","Plant","Valuation area"}, "ValuationArea"},
                         {{"Material","Material No","Material Number"},           "Material"},
                         {{"Nature","Tech","Technology"},                         "Nature"}
                     }),
            Cols   = {"ValuationArea","Material","Nature"},
            Padded = List.Accumulate(List.Difference(Cols, Table.ColumnNames(Raw)), Raw,
                         (t, c) => Table.AddColumn(t, c, each null)),
            Slim   = Table.SelectColumns(Padded, Cols),
            Keys   = Table.TransformColumns(Slim, {
                         {"ValuationArea", each Text.Trim(Text.From(_ ?? "")), type text},
                         {"Material",      each NormMat(_), type text},
                         {"Nature",        each Text.Trim(Text.From(_ ?? "")), type text}}),
            Real   = Table.SelectRows(Keys, each [Material] <> ""),
            Keyed  = Table.AddColumn(Real, "MatKey",
                         each [ValuationArea] & "|" & [Material], type text),
            Named  = Table.AddColumn(Keyed, "Sheet", each label, type text)
        in
            Table.SelectColumns(Named, {"Sheet","MatKey","Nature"}),
    RM      = Read({"RM Nature", "RM Master", "RMNature", "RM"}, "RM Nature"),
    FG      = Read({"FG Master", "FM Master", "FG Nature", "FGMaster", "FG"}, "FG Master"),
    Both    = Table.Combine({RM, FG}),
    Grouped = Table.Group(Both, {"Sheet","MatKey"}, {
                  {"Natures",  each List.Count(List.Distinct([Nature])), Int64.Type},
                  {"TheyAre",  each Text.Combine(List.Distinct([Nature]), " | "), type text},
                  {"Rows",     each Table.RowCount(_), Int64.Type}}),
    Clashes = Table.SelectRows(Grouped, each [Natures] > 1),
    Sorted  = Table.Sort(Clashes, {{"Sheet", Order.Ascending}, {"MatKey", Order.Ascending}})
in
    Sorted
