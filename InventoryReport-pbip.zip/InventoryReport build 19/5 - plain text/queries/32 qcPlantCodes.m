let
    Src     = Table.Combine({factRM, factFG, factConble}),
    Coded   = Table.AddColumn(Src, "Code",
                  each Text.Trim(Text.From([ValuationArea] ?? "")), type text),
    Named   = Table.TransformColumns(Coded, {
                  {"Code", each if _ = "" then "(blank)" else _, type text}}),
    Grouped = Table.Group(Named, {"Code"}, {
                  {"Rows",     each Table.RowCount(_), Int64.Type},
                  {"ValueRsCr", each List.Sum(List.Transform(_[CloseVal],
                                    each _ ?? 0)) / 10000000, type number}}),
    Flagged = Table.AddColumn(Grouped, "InReport",
                  each List.Contains({"1900","1902","1905"}, [Code]), type logical),
    Sorted  = Table.Sort(Flagged, {{"ValueRsCr", Order.Descending}})
in
    Sorted
