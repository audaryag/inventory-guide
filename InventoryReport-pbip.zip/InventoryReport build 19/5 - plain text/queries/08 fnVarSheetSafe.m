let
    fnVarSheetSafe = (sheetAliases as list, columnAliases as list) as table =>
        try fnVarSheet(sheetAliases, columnAliases)
        otherwise #table({}, {})
in
    fnVarSheetSafe
