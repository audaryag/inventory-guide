let
    Src     = factInventory,
    Grouped = Table.Group(Src, {"Category", "Month"}, {
                  {"Files",     each List.Count(List.Distinct([SourceFile])), Int64.Type},
                  {"FileNames", each Text.Combine(
                                    List.Transform(List.Distinct([SourceFile]), Text.From),
                                    " | "), type text},
                  {"Rows",      each Table.RowCount(_), Int64.Type},
                  {"ValueRsCr", each List.Sum(List.Transform([CloseVal], each _ ?? 0))
                                    / 10000000, type number}}),
    Sorted  = Table.Sort(Grouped, {{"Files", Order.Descending}, {"Month", Order.Descending}})
in
    Sorted
