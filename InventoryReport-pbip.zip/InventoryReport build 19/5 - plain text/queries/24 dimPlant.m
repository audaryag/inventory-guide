let
    // written out only as the fallback for a Plant Master sheet that is missing or empty
    Fallback = #table(
        type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type],
        {
            {"1900", "1900 Jaipur Module",  1},
            {"1902", "1902 Dholera Module", 2},
            {"1905", "1905 Dholera Cell",   3}
        }),
    Master   = try dimPlantMaster otherwise Fallback,
    Named    = if Table.IsEmpty(Master) then Fallback else Master,
    // codes present in the stock files or the trial balance. Only other queries are read
    // here and no folder is opened, which is what keeps the firewall quiet.
    Seen     = List.Distinct(List.RemoveNulls(
                   List.Combine({factInventory[ValuationArea], factTB_Staged[ValuationArea]}))),
    // a named plant with nothing behind it is left out, so the Plant slicer lists what the
    // files actually contain and not a fixed list padded with rows that pick nothing
    Live     = Table.SelectRows(Named, each List.Contains(Seen, [ValuationArea])),
    Kept     = if Table.IsEmpty(Live) then Named else Live,
    Dedup    = Table.Distinct(Kept, {"ValuationArea"}),
    Ren      = Table.RenameColumns(Dedup, {{"PlantSortNo", "PlantSort"}}),
    Typed    = Table.TransformColumnTypes(Ren, {
                   {"ValuationArea", type text}, {"Plant", type text},
                   {"PlantSort", Int64.Type}})
in
    Typed
