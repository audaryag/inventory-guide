let
    Norm     = (v as any) as text => Text.Upper(Text.Remove(Text.Trim(Text.From(v ?? "")), {" ",".","_","-","/","(",")"})),
    Sheets   = Table.SelectRows(varWorkbook, each [Kind] = "Sheet"),
    Hit      = Table.SelectRows(Sheets, each List.Contains({"RMTECHNOLOGYCOSTS","RMTECHCOSTS","RMTECHNOLOGY"}, Norm([Item]))),
    Data     = if Table.IsEmpty(Hit) then #table({}, {}) else Hit{0}[Data],
    Raw      = if Table.IsEmpty(Hit) then #table({}, {}) else Table.PromoteHeaders(Data, [PromoteAllScalars=true]),
    Names    = Table.ColumnNames(Raw),
    GroupCol = List.First(List.Select(Names, each List.Contains({"PLANTGROUP","GROUP","TYPE"}, Norm(_))), null),
    ItemCol  = List.First(List.Select(Names, each List.Contains({"ITEM","COMPONENT","NATURE"}, Norm(_))), null),
    Fixed    = List.RemoveNulls({GroupCol, ItemCol}),
    DateCols = List.Select(List.Difference(Names, Fixed), each
                   (try Date.From(DateTime.FromText(Text.From(_))) otherwise
                    try Date.FromText(Text.BeforeDelimiter(Text.From(_), " ")) otherwise null) <> null),
    Kept     = if GroupCol = null or ItemCol = null then #table({}, {})
               else Table.SelectColumns(Raw, Fixed & DateCols),
    Named    = if Table.IsEmpty(Kept) then Kept else Table.RenameColumns(Kept, {{GroupCol,"PlantGroup"},{ItemCol,"Item"}}),
    Long     = if Table.IsEmpty(Named) then #table({}, {})
               else Table.UnpivotOtherColumns(Named, {"PlantGroup","Item"}, "EffectiveText", "Input"),
    Dated    = Table.AddColumn(Long, "EffectiveFrom", each
                   try Date.From(DateTime.FromText(Text.From([EffectiveText])))
                   otherwise try Date.FromText(Text.BeforeDelimiter(Text.From([EffectiveText]), " "))
                   otherwise null, type date),
    Costed   = Table.AddColumn(Dated, "CostINRWp", each
                   let t = Text.Trim(Text.From([Input] ?? ""))
                   in  if t = "" then null else if t = "-" then 0
                       else try Number.From([Input]) otherwise try Number.From(t) otherwise null,
                   type number),
    Clean    = Table.SelectRows(Costed, each [EffectiveFrom] <> null and [CostINRWp] <> null
                   and Text.Trim(Text.From([PlantGroup] ?? "")) <> ""
                   and Text.Trim(Text.From([Item] ?? "")) <> ""),
    Out      = Table.TransformColumns(Table.SelectColumns(Clean, {"EffectiveFrom","PlantGroup","Item","CostINRWp"}), {
                   {"PlantGroup", each Text.Proper(Text.Trim(Text.From(_))), type text},
                   {"Item", each Text.Trim(Text.From(_)), type text}}),
    Buffered = Table.Buffer(Out)
in
    Buffered
