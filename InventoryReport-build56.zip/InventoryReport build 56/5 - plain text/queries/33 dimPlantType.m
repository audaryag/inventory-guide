let
    Plants = dimPlant,
    Cats   = dimCategory,
    Cross  = Table.AddColumn(Plants, "cat", each Cats),
    Opened = Table.ExpandTableColumn(Cross, "cat", {"Category", "CategorySort"}),
    Keyed  = Table.AddColumn(Opened, "PlantType",
                 each Text.From([ValuationArea] ?? "") & "|" & Text.From([Category] ?? ""),
                 type text),
    // the label the Summary rows show: the plant exactly as the rest of the report names it,
    // then the type
    Label  = Table.AddColumn(Keyed, "Plant and Type",
                 each Text.From([Plant]) & "  —  " & Text.From([Category]), type text),
    Order  = Table.AddColumn(Label, "RowSort",
                 each Int64.From([PlantSort]) * 10 + Int64.From([CategorySort]), Int64.Type),
    Out    = Table.SelectColumns(Order,
                 {"PlantType", "Plant and Type", "Plant", "Category", "RowSort"}),
    Typed  = Table.TransformColumnTypes(Out, {
                 {"PlantType", type text}, {"Plant and Type", type text},
                 {"Plant", type text}, {"Category", type text}, {"RowSort", Int64.Type}})
in
    Typed
