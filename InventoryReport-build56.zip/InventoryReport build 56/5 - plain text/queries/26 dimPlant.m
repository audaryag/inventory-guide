let
    // The three plants and their names are decided here and nowhere else, so no sheet and no
    // The names come from the Plant Master sheet; the pairs below are only what the report
    // falls back to when that sheet names no plant at all, so a swapped pair on the sheet
    // is corrected on the sheet and nowhere else.
    Fixed    = #table(
        type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type],
        {
            {"1902", "1902 Jaipur Module",  1},
            {"1900", "1900 Dholera Module", 2},
            {"1905", "1905 Dholera Cell",   3}
        }),
    Master   = Table.Buffer(try dimPlantMaster otherwise #table(
                   type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type,
                               MWD = nullable number], {})),
    // codes the masters name, and codes the files themselves hold - the union of the two, so a
    // plant is reported whether it was declared or merely arrived
    Named    = if Table.IsEmpty(Master) then {"1900","1902","1905"}
               else Master[ValuationArea],
    Seen     = List.Distinct(List.RemoveNulls(
                   List.Transform(Named, each Text.Trim(Text.From(_ ?? ""))))),
    // The plants are the ones Plant Master and TB Master name, and that is the end of it. This
    // step used to read factInventory and factTB_Staged as well, to drop a plant that no file
    // had any stock for - and it cost a fortune: every query that touches dimPlant made both
    // fact tables run again, and each of those re-parses the workbook, which is why a refresh
    // that took five minutes came to take thirty. A declared plant with no stock now shows as
    // an empty row instead, which is the cheaper mistake and a visible one.
    Codes    = List.Select(Seen, each _ <> ""),
    // the label: the fixed name for the three, the Plant Master name for anything else it
    // names, and the bare code for a plant nobody has named yet
    MWDOf    = (c as text) as nullable number =>
                   let m = Table.SelectRows(Master, (r) => r[ValuationArea] = c)
                   in  if Table.IsEmpty(m) then null
                       else try Number.From(Table.First(m)[MWD]) otherwise null,
    // Plant Master decides the name. The built-in pairs are used only for a code that sheet
    // does not name, because a name written in two places is a name that can disagree with
    // itself - which is how Jaipur and Dholera came to be reading each other's figures.
    NameOf   = (c as text) as text =>
                   let m = Table.SelectRows(Master, (r) => r[ValuationArea] = c),
                       f = Table.SelectRows(Fixed,  (r) => r[ValuationArea] = c)
                   in  if not Table.IsEmpty(m)
                          and Text.Trim(Text.From(Table.First(m)[Plant] ?? "")) <> ""
                          then Table.First(m)[Plant]
                       else if not Table.IsEmpty(f) then Table.First(f)[Plant]
                       else c,
    // the three come first, in their own order; everything else after them, by code, so the
    // report reads the way it always has and a new plant is added at the end
    SortOf   = (c as text) as number =>
                   let f = Table.SelectRows(Fixed,  (r) => r[ValuationArea] = c),
                       m = Table.SelectRows(Master, (r) => r[ValuationArea] = c)
                   in  if not Table.IsEmpty(f) then Number.From(Table.First(f)[PlantSortNo])
                       else if not Table.IsEmpty(m)
                            then 100 + (try Number.From(Table.First(m)[PlantSortNo]) otherwise 0)
                       else 900 + (try Number.From(Text.Select(c, {"0".."9"})) otherwise 0),
    // Module or Cell - the two groups the RM sheet's lower block is built on: the cell plant
    // on one side, the module plants on the other. It is read off the plant's own name, so a
    // plant added to Plant Master falls on the right side without anyone editing this.
    GroupOf  = (label as text) as text =>
                   if Text.Contains(Text.Upper(label), "CELL") then "Cell" else "Module",
    Built    = Table.FromRecords(List.Transform(Codes, (c) =>
                   let label = NameOf(c) in
                   [ValuationArea = c, Plant = label, PlantSort = SortOf(c),
                    MWD = MWDOf(c), PlantGroup = GroupOf(label)]),
                   type table [ValuationArea = text, Plant = text, PlantSort = number,
                               MWD = nullable number, PlantGroup = text]),
    // if nothing has loaded yet, the three known plants still make a table, so the report opens
    Rows     = if List.IsEmpty(Codes)
               then Table.AddColumn(
                        Table.AddColumn(
                            Table.RenameColumns(Fixed, {{"PlantSortNo", "PlantSort"}}),
                            "MWD", each null, type number),
                        "PlantGroup",
                        each if Text.Contains(Text.Upper([Plant]), "CELL") then "Cell"
                             else "Module", type text)
               else Built,
    Dedup    = Table.Distinct(Rows, {"ValuationArea"}),
    Typed    = Table.TransformColumnTypes(Dedup, {
                   {"ValuationArea", type text}, {"Plant", type text},
                   {"PlantSort", Int64.Type}, {"MWD", type number},
                   {"PlantGroup", type text}})
in
    Typed
