let
    FromRM  = List.RemoveNulls(dimMaterialAttr[Nature]),
    FromFG  = List.RemoveNulls(dimFGAttr[Nature]),
    // (All) is the MW sheet saying 'this is the whole plant, not one technology'. It is a
    // capacity row, never a nature, and listing it here would draw it as a slice and a slicer tick.
    FromCap = List.Select(List.RemoveNulls(varMWCapacity[Tech]), each _ <> "(All)"),
    // 'Consumables' and 'Unassigned' are written by the fact queries rather than read from a
    // master sheet, so they have to be listed here as well. A nature that a fact row carries
    // and this table does not is what draws a slice labelled (Blank).
    All     = List.Distinct(List.Combine({FromRM, FromFG, FromCap,
                  {"Consumables", "Unassigned"}})),
    T       = Table.FromList(All, Splitter.SplitByNothing(), {"Nature"}),
    Typed   = Table.TransformColumnTypes(T, {{"Nature", type text}})
in
    Typed
