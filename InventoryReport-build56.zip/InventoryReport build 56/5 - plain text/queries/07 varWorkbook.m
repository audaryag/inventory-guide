let
    Bytes = Binary.Buffer(File.Contents(pVarsFile)),
    Book  = Excel.Workbook(Bytes, null, true),
    Out   = Table.Buffer(Book)
in
    Out
