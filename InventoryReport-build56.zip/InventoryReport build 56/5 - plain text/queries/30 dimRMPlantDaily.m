let
    Months   = List.Distinct(List.Sort(dimDate[Month])),
    Combos   = Table.Distinct(Table.SelectColumns(varRMPlantCosts, {"ValuationArea","Item"})),
    Grid     = Table.AddColumn(Combos, "Month", each Months),
    Expanded = Table.ExpandListColumn(Grid, "Month"),
    AsOfCost = (p as text, i as text, m as date) as nullable number =>
                   let rows = Table.SelectRows(varRMPlantCosts, each
                                   [ValuationArea] = p and [Item] = i and [EffectiveFrom] <= m),
                       sorted = Table.Sort(rows, {{"EffectiveFrom", Order.Descending}})
                   in if Table.IsEmpty(sorted) then null else sorted{0}[CostINRWp],
    AsOfConst = (n as text, m as date) as nullable number =>
                   let rows = Table.SelectRows(varRMConstants, each
                                   [ConstantName] = n and [EffectiveFrom] <= m),
                       sorted = Table.Sort(rows, {{"EffectiveFrom", Order.Descending}})
                   in if Table.IsEmpty(sorted) then null else sorted{0}[Value],
    Cost     = Table.AddColumn(Expanded, "CostINRWp", each
                   AsOfCost([ValuationArea], [Item], Date.From([Month])), type number),
    Named    = Table.AddColumn(Cost, "ConstantName", each
                   [ValuationArea] & " Plant Variable", type text),
    Variable = Table.AddColumn(Named, "PlantVariable", each
                   AsOfConst([ConstantName], Date.From([Month])), type number),
    Daily    = Table.AddColumn(Variable, "PerDayCostCr", each
                   if [CostINRWp] = null or [PlantVariable] = null then null
                   else [CostINRWp] * [PlantVariable] / 10, type number),
    Out      = Table.TransformColumnTypes(Table.SelectColumns(Daily,
                   {"Month","ValuationArea","Item","CostINRWp","PlantVariable","PerDayCostCr"}),
                   {{"Month", type date}, {"ValuationArea", type text}, {"Item", type text},
                    {"CostINRWp", type number}, {"PlantVariable", type number},
                    {"PerDayCostCr", type number}})
in
    Out
