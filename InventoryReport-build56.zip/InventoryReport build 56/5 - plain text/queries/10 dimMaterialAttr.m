let
    Raw      = fnVarSheetSafe(
                   {"RM Nature", "RM Master", "RMNature", "RM"},
                   {
                     {{"Valuation Area","Val Area","Plant","Valuation area"}, "ValuationArea"},
                     {{"Material","Material No","Material Number"},           "Material"},
                     {{"Material Description","Merterial Description","Material Desc",
                       "Material description"},                              "MaterialDescVar"},
                     {{"Nature"},                                             "Nature"},
                     {{"Group Nature","GroupNature","Nature Group"},           "GroupNature"},
                     {{"BOM Std Qty","BOM StdQty","BOMStdQty","Std Qty"},      "BOMStdQty"},
                     {{"Item"},                                               "Item"}
                   }),
    // same normalisation as fnCleanMB5B, so the two sides of the join cannot disagree
    // over punctuation, case or SAP's leading zeros
    NormMat  = (v as any) as text =>
                   let Bare = Text.Select(Text.Upper(Text.From(v ?? "")),
                                  {"A".."Z", "0".."9"}),
                       Cut  = Text.TrimStart(Bare, "0")
                   in  if Cut = "" and Bare <> "" then "0" else Cut,
    // a sheet that is missing, or missing a column, comes through empty rather than failing
    // the whole refresh; qcAttrMatch and qcVarSheets on Checks then say so out loud
    Cols     = {"ValuationArea","Material","MaterialDescVar","Nature","GroupNature",
                "BOMStdQty","Item"},
    Padded   = List.Accumulate(List.Difference(Cols, Table.ColumnNames(Raw)), Raw,
                   (t, c) => Table.AddColumn(t, c, each null)),
    Keys     = Table.TransformColumns(Padded, {
                   {"ValuationArea", each Text.Trim(Text.From(_ ?? "")), type text},
                   {"Material",      each NormMat(_), type text}}),
    NoBlank  = Table.SelectRows(Keys, each [Material] <> null and [Material] <> ""),
    MatKey   = Table.AddColumn(NoBlank, "MatKey",
                   each [ValuationArea] & "|" & [Material], type text),
    // cell-by-cell with a fallback, so one oddly typed cell on the sheet cannot error the row
    // and take the whole master table down with it
    Typed    = Table.TransformColumns(MatKey, {
                   {"Nature",      each Text.Trim(Text.From(_ ?? "")), type text},
                   {"GroupNature", each Text.Trim(Text.From(_ ?? "")), type text},
                   {"BOMStdQty",   each try Number.From(_) otherwise null, type number},
                   {"Item",        each Text.Trim(Text.From(_ ?? "")), type text}}),
    // a third key, on the description, for the case where the sheet keys its rows by
    // material description rather than by number: unmatched rows fall back to it last
    Present  = Table.ColumnNames(Typed),
    WithDesc = if List.Contains(Present, "MaterialDescVar") then Typed
               else Table.AddColumn(Typed, "MaterialDescVar", each null, type text),
    DescKey  = Table.AddColumn(WithDesc, "DescKey",
                   each Text.Upper(Text.Trim(Text.From([MaterialDescVar] ?? ""))), type text),
    Slim     = Table.SelectColumns(DescKey,
                   {"MatKey","Material","DescKey","Nature","GroupNature","BOMStdQty","Item"}),
    Dedup    = Table.Distinct(Slim, {"MatKey"}),
    Buffered = Table.Buffer(Dedup)
in
    Buffered
