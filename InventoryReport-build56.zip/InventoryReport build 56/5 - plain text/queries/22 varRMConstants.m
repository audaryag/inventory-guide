let
    Norm     = (v as any) as text => Text.Upper(Text.Remove(Text.Trim(Text.From(v ?? "")), {" ",".","_","-","/","(",")"})),
    Sheets   = Table.SelectRows(varWorkbook, each [Kind] = "Sheet"),
    Hit      = Table.SelectRows(Sheets, each List.Contains({"RMCONSTANTS","RMDAYSCONSTANTS"}, Norm([Item]))),
    Data     = if Table.IsEmpty(Hit) then #table({}, {}) else Hit{0}[Data],
    Raw      = if Table.IsEmpty(Hit) then #table({}, {}) else Table.PromoteHeaders(Data, [PromoteAllScalars=true]),
    Names    = Table.ColumnNames(Raw),
    NameCol  = List.First(List.Select(Names, each List.Contains({"CONSTANTNAME","CONSTANT","NAME"}, Norm(_))), null),
    DateCols = if NameCol = null then {} else List.Select(List.RemoveItems(Names, {NameCol}), each
                   (try Date.From(DateTime.FromText(Text.From(_))) otherwise
                    try Date.FromText(Text.BeforeDelimiter(Text.From(_), " ")) otherwise null) <> null),
    Kept     = if NameCol = null then #table({}, {}) else Table.SelectColumns(Raw, {NameCol} & DateCols),
    Named    = if Table.IsEmpty(Kept) then Kept else Table.RenameColumns(Kept, {{NameCol,"ConstantName"}}),
    Long     = if Table.IsEmpty(Named) then #table({}, {})
               else Table.UnpivotOtherColumns(Named, {"ConstantName"}, "EffectiveText", "Input"),
    Dated    = Table.AddColumn(Long, "EffectiveFrom", each
                   try Date.From(DateTime.FromText(Text.From([EffectiveText])))
                   otherwise try Date.FromText(Text.BeforeDelimiter(Text.From([EffectiveText]), " "))
                   otherwise null, type date),
    Valued   = Table.AddColumn(Dated, "Value", each
                   let t = Text.Trim(Text.From([Input] ?? ""))
                   in  if t = "" then null else if t = "-" then 0
                       else try Number.From([Input]) otherwise try Number.From(t) otherwise null,
                   type number),
    Clean    = Table.SelectRows(Valued, each [EffectiveFrom] <> null and [Value] <> null
                   and Text.Trim(Text.From([ConstantName] ?? "")) <> ""),
    Out      = Table.TransformColumns(Table.SelectColumns(Clean, {"EffectiveFrom","ConstantName","Value"}), {
                   {"ConstantName", each Text.Trim(Text.From(_)), type text}}),
    Buffered = Table.Buffer(Out)
in
    Buffered
