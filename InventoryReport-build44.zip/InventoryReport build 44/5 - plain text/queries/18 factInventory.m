let
    Combined = Table.Combine({factRM, factFG, factConble}),
    Wanted   = {"SourceFile","ValuationArea","Material","MatKey","MaterialDesc",
                "FromDate","ToDate","OpenQty","OpenVal","ReceiptQty","ReceiptVal",
                "IssueQty","IssueVal","CloseQty","CloseVal","BaseUOM","SpecialStock",
                "Currency","Month","Category","Nature","GroupNature","BOMStdQty","Item",
                "AttrMissing","MW","Rate","RateParseFailed","Mid","Base","INR_WP"},
    Padded   = List.Accumulate(List.Difference(Wanted, Table.ColumnNames(Combined)),
                   Combined, (t, c) => Table.AddColumn(t, c, each null)),
    Kept     = Table.SelectColumns(Padded, Wanted),
    Typed    = Table.TransformColumnTypes(Kept, {
                   {"SourceFile", type text}, {"ValuationArea", type text},
                   {"Material", type text}, {"MatKey", type text},
                   {"MaterialDesc", type text}, {"FromDate", type date},
                   {"ToDate", type date}, {"OpenQty", type number},
                   {"OpenVal", type number}, {"ReceiptQty", type number},
                   {"ReceiptVal", type number}, {"IssueQty", type number},
                   {"IssueVal", type number}, {"CloseQty", type number},
                   {"CloseVal", type number}, {"BaseUOM", type text},
                   {"SpecialStock", type text}, {"Currency", type text},
                   {"Month", type date}, {"Category", type text},
                   {"Nature", type text}, {"GroupNature", type text},
                   {"BOMStdQty", type number}, {"Item", type text},
                   {"AttrMissing", type logical}, {"MW", type number},
                   {"Rate", type number}, {"RateParseFailed", type logical},
                   {"Mid", type text}, {"Base", type text}, {"INR_WP", type number}}),
    // last line of defence against a blank category: whatever slipped through above is
    // named, so no visual anywhere can show a nameless (Blank) row
    NoNulls  = Table.TransformColumns(Typed, {
                   {"Nature",      each if _ = null or _ = "" then "Unassigned" else _, type text},
                   {"GroupNature", each if _ = null or _ = "" then "Unassigned" else _, type text}}),
    // The report covers the plants Plant Master names, and the trial balance's other plants
    // are deliberately ignored: they are real codes in SAP but no part of this report. A row
    // whose valuation area is blank, or is a code that sheet does not list, is dropped rather
    // than parked on an Unallocated row. qcPlantCodes on Checks lists every code the files
    // contained and what it was worth, so a dropped row is never a silent one.
    Plants   = varPlantCodes,
    OnePlant = Table.SelectRows(NoNulls,
                   each List.Contains(Plants, Text.Trim(Text.From([ValuationArea] ?? "")))),
    Trimmed  = Table.TransformColumns(OnePlant, {
                   {"ValuationArea", each Text.Trim(Text.From(_)), type text}}),
    // Duplicates. The same stock line can arrive twice - the same month exported twice into
    // the same folder, or a file copied under a second name - and two identical lines would
    // double that material's stock. A row is treated as the same line when its plant,
    // material, month, special stock, unit and every figure agree; the file it came from is
    // deliberately not part of that test, which is what catches the same month in two files.
    // Two genuinely different lines for one material in one month (different batch, different
    // special stock) differ in at least one figure and are both kept.
    DedupKey = {"ValuationArea","Material","Month","SpecialStock","BaseUOM",
                "OpenQty","OpenVal","ReceiptQty","ReceiptVal","IssueQty","IssueVal",
                "CloseQty","CloseVal","Category"},
    OneEach  = Table.Distinct(Trimmed, DedupKey),
    // One row per plant, material, month and type - because that is what an export holds. The
    // same material appears for several plants, but never twice for one plant in one month, so
    // a second line for the same four is the same balance arriving twice (a storage-location or
    // special-stock split, or a month re-exported) and adding them multiplies that material's
    // stock. The line kept is the one with the largest closing quantity, which is the whole
    // balance rather than a part of it.
    // One grouping pass does it. It used to be a full sort of the table, then a distinct, then
    // a second grouping for the counts, then a merge back onto the first - four passes over
    // fifty thousand rows, of which the sort alone holds the whole table in memory and cannot
    // fold. Table.Max picks the row inside each group as the group is formed, so the table is
    // walked once.
    Picked   = Table.Group(OneEach, {"ValuationArea", "Material", "Month", "Category"},
                   {{"Row", each Table.Max(_, "CloseQty"), type record}}),
    Unused   = Table.ExpandRecordColumn(Table.SelectColumns(Picked, {"Row"}), "Row",
                   Table.ColumnNames(OneEach)),
    // the column list written out, so what this query hands on is stated rather than inferred
    KeepCols = {"SourceFile","ValuationArea","Material","MatKey","MaterialDesc","FromDate",
                "ToDate","OpenQty","OpenVal","ReceiptQty","ReceiptVal","IssueQty","IssueVal",
                "CloseQty","CloseVal","BaseUOM","SpecialStock","Currency","Month","Category",
                "Nature","GroupNature","BOMStdQty","Item","AttrMissing","MW","Rate",
                "RateParseFailed","Mid","Base","INR_WP"},
    Collapsed = Table.SelectColumns(Unused, KeepCols),
    // the megawatt column is renamed because Power BI will not let a table hold a column
    // and a measure with the same name, and the report needs the measure to be called MW
    Renamed  = Table.RenameColumns(Collapsed, {{"MW", "MW Qty"}}),
    // the flat plant-and-type key. dimPlantType joins on it, which is what lets a matrix show
    // one row per plant AND type without a two-level row hierarchy - and a hierarchy is the
    // one thing some versions of Desktop insist on opening collapsed, hiding the rows.
    Keyed    = Table.AddColumn(Renamed, "PlantType",
                   each Text.From([ValuationArea] ?? "") & "|" & Text.From([Category] ?? ""),
                   type text)
in
    Keyed
