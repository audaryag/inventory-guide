let
    // The three plants and their names are decided here and nowhere else, so no sheet and no
    // page can call 1900 anything but Jaipur Module.
    Fixed    = #table(
        type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type],
        {
            {"1900", "1900 Jaipur Module",  1},
            {"1902", "1902 Dholera Module", 2},
            {"1905", "1905 Dholera Cell",   3}
        }),
    Master   = try dimPlantMaster otherwise #table(
                   type table [ValuationArea = text, Plant = text, PlantSortNo = Int64.Type], {}),
    // codes the masters name, and codes the files themselves hold - the union of the two, so a
    // plant is reported whether it was declared or merely arrived
    Named    = try varPlantCodes otherwise {"1900","1902","1905"},
    Seen     = List.Distinct(List.RemoveNulls(
                   List.Transform(Named, each Text.Trim(Text.From(_ ?? ""))))),
    // a plant with nothing behind it is left out, so the slicer lists what the files contain
    Live     = List.Distinct(List.RemoveNulls(
                   List.Combine({
                       List.Transform(factInventory[ValuationArea],
                           each Text.Trim(Text.From(_ ?? ""))),
                       List.Transform(factTB_Staged[ValuationArea],
                           each Text.Trim(Text.From(_ ?? "")))}))),
    Named2   = List.Select(Seen, each _ <> ""),
    Codes    = let k = List.Select(Named2, each List.Contains(Live, _))
               in  if List.IsEmpty(k) then Named2 else k,
    // the label: the fixed name for the three, the Plant Master name for anything else it
    // names, and the bare code for a plant nobody has named yet
    MWDOf    = (c as text) as nullable number =>
                   let m = Table.SelectRows(Master, (r) => r[ValuationArea] = c)
                   in  if Table.IsEmpty(m) then null
                       else try Number.From(Table.First(m)[MWD]) otherwise null,
    NameOf   = (c as text) as text =>
                   let f = Table.SelectRows(Fixed,  (r) => r[ValuationArea] = c),
                       m = Table.SelectRows(Master, (r) => r[ValuationArea] = c)
                   in  if not Table.IsEmpty(f) then Table.First(f)[Plant]
                       else if not Table.IsEmpty(m)
                            and Text.Trim(Text.From(Table.First(m)[Plant] ?? "")) <> ""
                            then Table.First(m)[Plant]
                       else c,
    // the three come first, in their own order; everything else after them, by code, so the
    // report reads the way it always has and a new plant is added at the end
    SortOf   = (c as text) as number =>
                   let f = Table.SelectRows(Fixed,  (r) => r[ValuationArea] = c),
                       m = Table.SelectRows(Master, (r) => r[ValuationArea] = c)
                   in  if not Table.IsEmpty(f) then Number.From(Table.First(f)[PlantSortNo])
                       else if not Table.IsEmpty(m)
                            then 100 + (try Number.From(Table.First(m)[PlantSortNo]) otherwise 0)
                       else 900 + (try Number.From(Text.Select(c, {"0".."9"})) otherwise 0),
    Built    = Table.FromRecords(List.Transform(Codes, (c) =>
                   [ValuationArea = c, Plant = NameOf(c), PlantSort = SortOf(c),
                    MWD = MWDOf(c)]),
                   type table [ValuationArea = text, Plant = text, PlantSort = number,
                               MWD = nullable number]),
    // if nothing has loaded yet, the three known plants still make a table, so the report opens
    Rows     = if List.IsEmpty(Codes)
               then Table.AddColumn(
                        Table.RenameColumns(Fixed, {{"PlantSortNo", "PlantSort"}}),
                        "MWD", each null, type number)
               else Built,
    Dedup    = Table.Distinct(Rows, {"ValuationArea"}),
    Typed    = Table.TransformColumnTypes(Dedup, {
                   {"ValuationArea", type text}, {"Plant", type text},
                   {"PlantSort", Int64.Type}, {"MWD", type number}})
in
    Typed
